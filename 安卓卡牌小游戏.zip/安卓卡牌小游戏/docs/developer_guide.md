# 元素对战 - 开发者指南

本文档为开发者提供详细的技术实现说明和扩展指南。

## 🏗️ 架构概览

### 整体架构
项目采用 Clean Architecture + MVVM 模式：

```
┌─────────────────────────────────────┐
│              UI Layer               │
│  (Compose UI + ViewModels)          │
├─────────────────────────────────────┤
│            Domain Layer             │
│  (Use Cases + Entities + Repository │
│   Interfaces)                       │
├─────────────────────────────────────┤
│             Data Layer              │
│  (Repository Impl + Data Sources)   │
├─────────────────────────────────────┤
│          Infrastructure             │
│  (Database + Audio + Preferences)   │
└─────────────────────────────────────┘
```

### 依赖关系
- UI Layer → Domain Layer
- Domain Layer ← Data Layer
- Data Layer → Infrastructure

## 📦 模块详解

### UI Layer (`ui/`)
负责用户界面展示和用户交互。

#### 主要组件
- **Screens**: 各个界面的Composable函数
- **Components**: 可复用的UI组件
- **ViewModels**: 管理UI状态和业务逻辑调用
- **Navigation**: 界面导航逻辑
- **Theme**: 主题和样式定义

#### 关键文件
```kotlin
// 主要界面
MainMenuScreen.kt      // 主菜单
GameScreen.kt          // 游戏界面
GameOverScreen.kt      // 游戏结束界面
SettingsScreen.kt      // 设置界面

// 可复用组件
CardComponent.kt       // 卡牌组件
PlayerInfoComponent.kt // 玩家信息组件

// ViewModel
GameViewModel.kt       // 游戏状态管理
```

### Domain Layer (`domain/`)
包含业务逻辑和核心实体。

#### 实体类 (`entities/`)
```kotlin
Element.kt      // 元素枚举和相克逻辑
Card.kt         // 卡牌实体
Player.kt       // 玩家实体
GameState.kt    // 游戏状态
```

#### 用例 (`usecases/`)
```kotlin
GameEngine.kt   // 游戏引擎核心逻辑
AIStrategy.kt   // AI策略接口和实现
CardFactory.kt  // 卡牌工厂
```

### Data Layer (`data/`)
处理数据存储和外部数据源。

#### 主要组件
```kotlin
ResourceManager.kt     // 资源管理
AudioManager.kt        // 音频管理
PreferencesManager.kt  // 设置存储
```

## 🎮 核心系统实现

### 1. 游戏引擎 (GameEngine)

```kotlin
class GameEngine @Inject constructor(
    private val cardFactory: CardFactory,
    private val aiStrategy: AIStrategy
) {
    fun startNewGame(): GameState.Playing
    fun playCard(gameState: GameState.Playing, card: Card): GameState
    fun attackCard(gameState: GameState.Playing, attacker: Card, target: Card): GameState
    fun endTurn(gameState: GameState.Playing): GameState
    suspend fun processAITurn(gameState: GameState.Playing): GameState
}
```

**职责**：
- 管理游戏状态转换
- 处理玩家操作
- 执行AI回合
- 检查游戏结束条件

### 2. 元素系统 (Element)

```kotlin
enum class Element {
    FIRE, WATER, EARTH, WIND;

    fun getAdvantageAgainst(): Element
    fun getDamageMultiplier(target: Element): Float
}
```

**相克关系实现**：
- 使用枚举的when表达式实现相克逻辑
- 伤害倍率：克制1.5x，被克制0.75x，其他1.0x

### 3. AI系统 (AIStrategy)

```kotlin
interface AIStrategy {
    suspend fun selectCardToPlay(...): Card?
    suspend fun selectAttackTarget(...): AITarget
}
```

**AI策略类型**：
- `SimpleAIStrategy`: 基础AI，优先出费用高的牌
- `AggressiveAIStrategy`: 激进AI，优先攻击玩家
- `DefensiveAIStrategy`: 防守AI，优先清理威胁

### 4. 状态管理 (GameViewModel)

```kotlin
@HiltViewModel
class GameViewModel @Inject constructor(
    private val gameEngine: GameEngine
) : ViewModel() {
    private val _gameState = MutableStateFlow<GameState>(GameState.MainMenu)
    val gameState: StateFlow<GameState> = _gameState.asStateFlow()

    fun startNewGame()
    fun playCard(card: Card)
    fun endTurn()
}
```

**状态流转**：
MainMenu → Loading → Playing → GameOver → MainMenu

## 🎨 UI实现详解

### Jetpack Compose使用

#### 主题系统
```kotlin
@Composable
fun ElementBattleTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = if (darkTheme) DarkColorScheme else LightColorScheme,
        typography = Typography,
        content = content
    )
}
```

#### 卡牌组件
```kotlin
@Composable
fun CardComponent(
    card: Card,
    isPlayable: Boolean,
    isSelected: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    // 卡牌UI实现
}
```

### 动画系统
使用Compose Animation API实现：
- 卡牌出牌动画
- 攻击效果动画
- 界面切换动画
- 数值变化动画

## 🔊 音频系统

### AudioManager实现
```kotlin
@Singleton
class AudioManager @Inject constructor(
    @ApplicationContext private val context: Context
) {
    private var soundPool: SoundPool?
    private var backgroundMusicPlayer: MediaPlayer?

    fun playSound(effect: SoundEffect)
    fun startBackgroundMusic(musicType: BackgroundMusic)
    fun stopBackgroundMusic()
}
```

### 音频资源管理
- 音效使用SoundPool预加载
- 背景音乐使用MediaPlayer循环播放
- 支持音量控制和开关设置

## 🧪 测试策略

### 单元测试
```kotlin
class ElementTest {
    @Test
    fun `test element advantage relationships`() {
        assertEquals(Element.WIND, Element.FIRE.getAdvantageAgainst())
        // ...
    }
}
```

### 集成测试
```kotlin
@HiltAndroidTest
class MainActivityTest {
    @Test
    fun testGameFlow() {
        composeTestRule.onNodeWithText("开始游戏").performClick()
        // ...
    }
}
```

### 性能测试
```kotlin
class PerformanceTest {
    @Test
    fun `test game initialization performance`() {
        val time = measureTimeMillis {
            gameEngine.startNewGame()
        }
        assertTrue(time < 100) // 应在100ms内完成
    }
}
```

## 🔧 扩展指南

### 添加新卡牌
1. 在`CardFactory`中添加卡牌定义
2. 如需特殊效果，扩展`Card`实体
3. 更新UI资源（图标、描述等）
4. 添加相应测试

### 添加新AI策略
1. 实现`AIStrategy`接口
2. 在`GameModule`中配置依赖注入
3. 添加策略选择逻辑
4. 编写测试验证策略效果

### 添加新界面
1. 创建Composable函数
2. 在`Navigation`中添加路由
3. 如需状态管理，创建对应ViewModel
4. 添加UI测试

### 添加新音效
1. 将音频文件放入`res/raw/`目录
2. 在`SoundEffect`枚举中添加新项
3. 在`AudioManager`中加载音效
4. 在适当位置调用播放

## 📊 性能优化

### 内存优化
- 使用对象池管理卡牌实例
- 及时释放不用的资源
- 避免内存泄漏

### 渲染优化
- 使用Compose的LazyColumn优化列表
- 实现卡牌预加载机制
- 合理使用动画避免过度绘制

### 电池优化
- 合理控制动画频率
- 优化AI计算复杂度
- 在后台时暂停不必要的操作

## 🔒 安全考虑

### 代码保护
- 使用ProGuard混淆代码
- 避免在代码中硬编码敏感信息
- 实现基本的反调试机制

### 数据安全
- 本地数据加密存储
- 防止内存dump获取信息
- 游戏状态完整性检查

## 📱 兼容性

### Android版本支持
- 最低支持：Android 6.0 (API 23)
- 目标版本：Android 14 (API 34)
- 测试覆盖：API 23-34

### 设备适配
- 屏幕尺寸：4.5-7英寸
- 分辨率：自适应
- 内存：最低2GB，推荐4GB+

## 🚀 部署流程

### 构建配置
```gradle
android {
    buildTypes {
        release {
            minifyEnabled true
            shrinkResources true
            proguardFiles getDefaultProguardFile('proguard-android-optimize.txt'), 'proguard-rules.pro'
            signingConfig signingConfigs.release
        }
    }
}
```

### 自动化构建
使用提供的脚本：
```bash
./scripts/build_release.sh
```

## 📞 技术支持

### 开发问题
- GitHub Issues: 提交bug报告和功能请求
- 技术邮箱: dev@elementbattle.com
- 开发者QQ群: 987654321

### 代码贡献
1. Fork项目
2. 创建功能分支
3. 提交代码并编写测试
4. 发起Pull Request
5. 代码审查和合并

---

**Happy Coding!** 🎉
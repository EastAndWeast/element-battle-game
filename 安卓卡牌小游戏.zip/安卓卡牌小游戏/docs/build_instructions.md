# 元素对战 - 构建说明

## 🚨 重要提示

由于当前环境缺少Java运行时环境，无法直接执行APK构建。以下是在完整Android开发环境中构建APK的详细步骤。

## 📋 环境要求

### 必需软件
1. **Java JDK 8或更高版本**
   ```bash
   # 检查Java版本
   java -version
   javac -version
   ```

2. **Android Studio** (推荐) 或 **Android SDK Command Line Tools**
   - 下载地址：https://developer.android.com/studio

3. **Android SDK**
   - API Level 23+ (Android 6.0+)
   - Build Tools 30.0.0+

### 环境变量设置
```bash
# 添加到 ~/.bashrc 或 ~/.zshrc
export ANDROID_HOME=$HOME/Android/Sdk
export PATH=$PATH:$ANDROID_HOME/emulator
export PATH=$PATH:$ANDROID_HOME/tools
export PATH=$PATH:$ANDROID_HOME/tools/bin
export PATH=$PATH:$ANDROID_HOME/platform-tools
```

## 🔐 步骤1：生成签名密钥

### 自动生成（推荐）
```bash
./scripts/generate_keystore.sh
```

### 手动生成
```bash
keytool -genkey -v -keystore app/release-key.keystore \
    -alias elementbattle -keyalg RSA -keysize 2048 \
    -validity 10000 -storepass elementbattle2024 \
    -keypass elementbattle2024 \
    -dname "CN=Element Battle, OU=Game Development, O=Element Battle Studio, L=Shanghai, ST=Shanghai, C=CN"
```

## 🏗️ 步骤2：构建APK

### 方法1：使用自动化脚本（推荐）
```bash
# 完整构建（包含测试）
./scripts/build_release.sh

# 快速构建（跳过测试）
./scripts/build_release.sh --skip-tests
```

### 方法2：使用Gradle命令
```bash
# 清理项目
./gradlew clean

# 构建发布版本
./gradlew assembleRelease

# 构建调试版本
./gradlew assembleDebug
```

### 方法3：使用Android Studio
1. 打开Android Studio
2. 导入项目
3. 选择 Build → Generate Signed Bundle / APK
4. 选择APK
5. 选择release密钥库
6. 点击Build

## 📱 步骤3：安装APK

### 构建输出位置
- **发布版本**：`app/build/outputs/apk/release/app-release.apk`
- **调试版本**：`app/build/outputs/apk/debug/app-debug.apk`
- **发布目录**：`releases/v1.0/ElementBattle-v1.0.apk`

### 安装到设备
```bash
# 通过ADB安装
adb install app/build/outputs/apk/release/app-release.apk

# 或者直接传输到设备安装
```

## 🔧 故障排除

### 常见问题

#### 1. Java未安装
```
错误：Unable to locate a Java Runtime
解决：安装Java JDK 8+
```

#### 2. Android SDK未找到
```
错误：SDK location not found
解决：设置ANDROID_HOME环境变量
```

#### 3. 签名配置错误
```
错误：Keystore file not found
解决：运行 ./scripts/generate_keystore.sh
```

#### 4. 构建失败
```bash
# 清理并重新构建
./gradlew clean
./gradlew build --refresh-dependencies
```

## 📊 构建验证

### 检查APK信息
```bash
# 查看APK信息
aapt dump badging app/build/outputs/apk/release/app-release.apk

# 验证签名
jarsigner -verify -verbose -certs app/build/outputs/apk/release/app-release.apk
```

### 测试安装
1. 在Android设备上启用"未知来源"安装
2. 传输APK文件到设备
3. 点击安装
4. 启动游戏测试功能

## 🚀 自动化构建

### CI/CD集成
项目包含GitHub Actions配置（如果需要）：

```yaml
# .github/workflows/build.yml
name: Build APK
on: [push, pull_request]
jobs:
  build:
    runs-on: ubuntu-latest
    steps:
    - uses: actions/checkout@v2
    - name: Set up JDK
      uses: actions/setup-java@v2
      with:
        java-version: '11'
        distribution: 'adopt'
    - name: Build APK
      run: ./gradlew assembleRelease
```

## 📦 发布准备

### 应用商店发布
1. **Google Play Console**
   - 创建应用
   - 上传APK或AAB
   - 填写应用信息
   - 提交审核

2. **其他应用商店**
   - 华为应用市场
   - 小米应用商店
   - 应用宝等

### 版本管理
更新版本号：
```gradle
// app/build.gradle
android {
    defaultConfig {
        versionCode 2
        versionName "1.1"
    }
}
```

## 📞 技术支持

如果在构建过程中遇到问题：

1. **检查环境**：确保Java和Android SDK正确安装
2. **查看日志**：构建失败时查看详细错误信息
3. **清理重建**：尝试clean后重新构建
4. **联系支持**：发送错误日志到 dev@elementbattle.com

---

**构建成功后，您就可以在Android设备上享受《元素对战》游戏了！** 🎮
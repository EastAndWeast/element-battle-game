# 元素对战 - 技术架构文档

## 1. 技术栈选择

### 1.1 开发平台
- **主要平台**：Android (API Level 23+)
- **开发语言**：Kotlin (100%)
- **最低版本**：Android 6.0 (API 23)
- **目标版本**：Android 14 (API 34)

### 1.2 核心框架
- **UI框架**：Jetpack Compose
- **架构模式**：MVVM + Repository Pattern
- **依赖注入**：Hilt
- **异步处理**：Kotlin Coroutines + Flow
- **本地存储**：Room Database
- **音频处理**：MediaPlayer + SoundPool

### 1.3 第三方库
```kotlin
// UI & Animation
implementation "androidx.compose.ui:ui:$compose_version"
implementation "androidx.compose.animation:animation:$compose_version"
implementation "com.airbnb.android:lottie-compose:$lottie_version"

// Architecture
implementation "androidx.lifecycle:lifecycle-viewmodel-compose:$lifecycle_version"
implementation "androidx.navigation:navigation-compose:$nav_version"
implementation "com.google.dagger:hilt-android:$hilt_version"

// Database
implementation "androidx.room:room-runtime:$room_version"
implementation "androidx.room:room-ktx:$room_version"

// Testing
testImplementation "junit:junit:4.13.2"
androidTestImplementation "androidx.compose.ui:ui-test-junit4:$compose_version"
```

## 2. 系统架构设计

### 2.1 整体架构
```
┌─────────────────────────────────────┐
│              UI Layer               │
│  (Compose UI + ViewModels)          │
├─────────────────────────────────────┤
│            Domain Layer             │
│  (Use Cases + Entities + Repository │
│   Interfaces)                       │
├─────────────────────────────────────┤
│             Data Layer              │
│  (Repository Impl + Data Sources)   │
├─────────────────────────────────────┤
│          Infrastructure             │
│  (Database + Audio + Preferences)   │
└─────────────────────────────────────┘
```

### 2.2 模块划分
```
app/
├── ui/                 # UI层
│   ├── screens/        # 各个界面
│   ├── components/     # 可复用组件
│   ├── theme/          # 主题样式
│   └── navigation/     # 导航逻辑
├── domain/             # 业务逻辑层
│   ├── entities/       # 实体类
│   ├── usecases/       # 用例
│   └── repository/     # 仓库接口
├── data/               # 数据层
│   ├── repository/     # 仓库实现
│   ├── database/       # 数据库
│   ├── preferences/    # 偏好设置
│   └── audio/          # 音频管理
└── di/                 # 依赖注入
```

## 3. 核心组件设计

### 3.1 游戏状态管理
```kotlin
sealed class GameState {
    object MainMenu : GameState()
    object Loading : GameState()
    data class Playing(
        val playerHealth: Int,
        val enemyHealth: Int,
        val currentTurn: Player,
        val playerHand: List<Card>,
        val playerField: List<Card>,
        val enemyField: List<Card>
    ) : GameState()
    data class GameOver(val winner: Player) : GameState()
}
```

### 3.2 卡牌系统
```kotlin
data class Card(
    val id: String,
    val name: String,
    val element: Element,
    val attack: Int,
    val health: Int,
    val manaCost: Int,
    val description: String,
    val imageRes: Int
)

enum class Element {
    FIRE, WATER, EARTH, WIND;

    fun getAdvantageAgainst(): Element = when(this) {
        FIRE -> WIND
        WIND -> EARTH
        EARTH -> WATER
        WATER -> FIRE
    }
}
```

### 3.3 AI系统
```kotlin
interface AIStrategy {
    suspend fun selectCard(
        hand: List<Card>,
        field: List<Card>,
        enemyField: List<Card>,
        availableMana: Int
    ): Card?

    suspend fun selectTarget(
        availableTargets: List<Card>
    ): Card?
}

class SimpleAI : AIStrategy {
    // 简单AI实现：优先出费用低的牌
    // 攻击时优先攻击生命值低的敌方卡牌
}
```

## 4. 数据库设计

### 4.1 数据表结构
```sql
-- 卡牌表
CREATE TABLE cards (
    id TEXT PRIMARY KEY,
    name TEXT NOT NULL,
    element TEXT NOT NULL,
    attack INTEGER NOT NULL,
    health INTEGER NOT NULL,
    mana_cost INTEGER NOT NULL,
    description TEXT,
    image_res INTEGER
);

-- 游戏记录表
CREATE TABLE game_records (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    player_score INTEGER,
    enemy_score INTEGER,
    winner TEXT,
    duration INTEGER,
    created_at INTEGER
);

-- 用户设置表
CREATE TABLE user_settings (
    key TEXT PRIMARY KEY,
    value TEXT
);
```

## 5. 性能优化策略

### 5.1 内存管理
- 使用对象池管理卡牌实例
- 及时释放不用的Bitmap资源
- 使用WeakReference避免内存泄漏

### 5.2 渲染优化
- 使用Compose的LazyColumn优化列表渲染
- 实现卡牌的预加载和缓存机制
- 动画使用硬件加速

### 5.3 音频优化
- 预加载常用音效到SoundPool
- 背景音乐使用MediaPlayer循环播放
- 支持音效开关和音量调节

## 6. 安全考虑

### 6.1 数据安全
- 本地数据库加密存储
- 防止内存dump获取敏感信息
- 代码混淆保护

### 6.2 作弊防护
- 游戏逻辑服务端验证（未来扩展）
- 客户端数据完整性检查
- 异常行为检测

## 7. 测试策略

### 7.1 单元测试
- 游戏逻辑核心算法测试
- 数据层Repository测试
- ViewModel业务逻辑测试

### 7.2 UI测试
- Compose UI组件测试
- 用户交互流程测试
- 屏幕适配测试

### 7.3 集成测试
- 数据库操作测试
- 音频播放测试
- 完整游戏流程测试
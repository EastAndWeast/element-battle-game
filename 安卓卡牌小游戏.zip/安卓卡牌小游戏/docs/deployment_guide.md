# 元素对战 - 部署指南

本文档详细说明如何部署和发布元素对战游戏。

## 📋 部署前准备

### 1. 环境检查
确保以下工具已正确安装：

```bash
# 检查Java版本
java -version

# 检查Android SDK
echo $ANDROID_HOME

# 检查Gradle
./gradlew --version
```

### 2. 项目配置
- 确保所有依赖项已正确配置
- 检查 `build.gradle` 中的版本号
- 验证签名配置文件存在

## 🔐 签名配置

### 1. 生成发布密钥库
```bash
# 使用提供的脚本生成密钥库
./scripts/generate_keystore.sh

# 或手动生成
keytool -genkey -v -keystore app/release-key.keystore \
    -alias elementbattle -keyalg RSA -keysize 2048 \
    -validity 10000 -storepass your_password \
    -keypass your_password
```

### 2. 配置签名信息
编辑 `app/keystore.properties` 文件：
```properties
storeFile=release-key.keystore
storePassword=your_store_password
keyAlias=elementbattle
keyPassword=your_key_password
```

⚠️ **安全提醒**：
- 不要将密钥库文件提交到版本控制
- 使用强密码保护密钥库
- 备份密钥库文件到安全位置

## 🏗️ 构建流程

### 1. 自动化构建
使用提供的构建脚本：
```bash
# 完整构建（包含测试）
./scripts/build_release.sh

# 跳过测试的快速构建
./scripts/build_release.sh --skip-tests
```

### 2. 手动构建
```bash
# 清理项目
./gradlew clean

# 运行测试
./gradlew test
./gradlew connectedAndroidTest

# 构建发布版本
./gradlew assembleRelease
```

### 3. 构建输出
构建成功后，APK文件位于：
- 原始位置：`app/build/outputs/apk/release/app-release.apk`
- 发布目录：`releases/v{version}/ElementBattle-v{version}.apk`

## 📱 APK安装与测试

### 1. 安装到设备
```bash
# 通过ADB安装
adb install releases/v1.0/ElementBattle-v1.0.apk

# 或直接传输到设备安装
```

### 2. 测试检查清单
- [ ] 应用正常启动
- [ ] 主菜单显示正确
- [ ] 游戏流程完整
- [ ] 音效正常播放
- [ ] 设置功能可用
- [ ] 游戏结束流程正常
- [ ] 内存使用合理
- [ ] 电池消耗正常

## 🚀 发布渠道

### 1. Google Play Store
1. 创建开发者账户
2. 上传APK或AAB文件
3. 填写应用信息
4. 设置定价和分发
5. 提交审核

### 2. 其他应用商店
- 华为应用市场
- 小米应用商店
- OPPO软件商店
- vivo应用商店
- 应用宝（腾讯）

### 3. 直接分发
- 通过官网提供APK下载
- 使用二维码分享
- 通过邮件或即时通讯工具分发

## 📊 版本管理

### 1. 版本号规则
- **versionName**: 语义化版本 (如 1.0.0)
- **versionCode**: 递增整数 (如 1, 2, 3...)

### 2. 发布流程
1. 更新版本号
2. 更新变更日志
3. 运行完整测试
4. 构建发布版本
5. 内部测试验证
6. 上传到应用商店
7. 发布公告

### 3. 回滚计划
如果发现严重问题：
1. 立即从应用商店下架
2. 修复问题
3. 发布热修复版本
4. 通知用户更新

## 🔍 监控与维护

### 1. 性能监控
- 应用启动时间
- 内存使用情况
- 电池消耗
- 崩溃率统计

### 2. 用户反馈
- 应用商店评论
- 用户支持邮箱
- 社交媒体反馈
- 应用内反馈系统

### 3. 更新策略
- 定期安全更新
- 功能增强更新
- 问题修复更新
- 兼容性更新

## 🛠️ 故障排除

### 常见问题

#### 构建失败
```bash
# 清理并重新构建
./gradlew clean
./gradlew build --refresh-dependencies
```

#### 签名错误
- 检查密钥库文件路径
- 验证密码正确性
- 确认密钥别名存在

#### 安装失败
- 检查设备存储空间
- 确认允许未知来源安装
- 卸载旧版本后重新安装

#### 运行时崩溃
- 检查日志输出
- 验证权限配置
- 测试不同设备和系统版本

## 📞 支持联系

如遇到部署问题，请联系：
- 技术支持：tech-support@elementbattle.com
- 开发团队：dev-team@elementbattle.com
- 紧急联系：emergency@elementbattle.com

---

**祝部署顺利！** 🎉
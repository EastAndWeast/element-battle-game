# 🚀 GitHub自动构建APK指南

## 📋 概述

我已经为您设置了GitHub Actions自动构建系统，可以在云端自动编译生成APK文件。

## 🔧 使用步骤

### 步骤1：上传到GitHub

1. **创建GitHub账户**（如果没有）
   - 访问 https://github.com
   - 注册免费账户

2. **创建新仓库**
   - 点击右上角 "+" → "New repository"
   - 仓库名称：`element-battle-game`
   - 设置为Public（免费用户）
   - 点击 "Create repository"

3. **上传项目文件**

   **方法A：使用GitHub网页界面**
   - 将整个项目文件夹压缩成ZIP
   - 在GitHub仓库页面点击 "uploading an existing file"
   - 拖拽ZIP文件上传
   - 解压后提交

   **方法B：使用Git命令**（如果您会用Git）
   ```bash
   git init
   git add .
   git commit -m "Initial commit"
   git remote add origin https://github.com/您的用户名/element-battle-game.git
   git push -u origin main
   ```

### 步骤2：触发自动构建

上传完成后，GitHub Actions会自动开始构建：

1. **查看构建状态**
   - 在仓库页面点击 "Actions" 标签
   - 可以看到构建进度

2. **构建时间**
   - 首次构建：约10-15分钟
   - 后续构建：约5-8分钟

### 步骤3：下载APK文件

构建完成后：

1. **在Actions页面**
   - 点击最新的构建任务
   - 滚动到底部的 "Artifacts" 部分
   - 下载 `ElementBattle-Release` 或 `ElementBattle-Debug`

2. **在Releases页面**（如果是main分支）
   - 点击仓库的 "Releases" 标签
   - 下载最新版本的APK文件

## 📱 APK文件说明

### Debug版本 (`app-debug.apk`)
- **用途**：开发测试
- **签名**：Debug签名
- **大小**：约20-30MB
- **安装**：需要启用"未知来源"

### Release版本 (`app-release.apk`)
- **用途**：正式发布
- **签名**：Release签名
- **大小**：约15-25MB（经过优化）
- **安装**：需要启用"未知来源"

## 🔄 手动触发构建

如果需要重新构建：

1. 进入仓库的 "Actions" 页面
2. 点击 "Build APK" 工作流
3. 点击 "Run workflow" 按钮
4. 选择分支并点击 "Run workflow"

## 📊 构建过程详解

GitHub Actions会自动执行以下步骤：

1. **环境准备**
   - 设置Ubuntu Linux环境
   - 安装Java JDK 11
   - 安装Android SDK

2. **代码准备**
   - 下载您的项目代码
   - 缓存Gradle依赖

3. **签名配置**
   - 自动生成签名密钥
   - 配置APK签名

4. **编译构建**
   - 编译Kotlin代码
   - 打包资源文件
   - 生成APK文件

5. **上传结果**
   - 上传APK到Artifacts
   - 创建Release（如果是主分支）

## 🛠️ 故障排除

### 构建失败
如果构建失败：

1. **查看错误日志**
   - 在Actions页面点击失败的构建
   - 查看详细错误信息

2. **常见问题**
   - 代码语法错误
   - 依赖版本冲突
   - 资源文件缺失

3. **解决方法**
   - 修复代码问题
   - 重新提交代码
   - 构建会自动重新开始

### 无法下载APK
如果无法下载：

1. **检查构建状态**
   - 确保构建成功完成
   - 绿色✅表示成功

2. **检查Artifacts**
   - 构建成功后会有Artifacts
   - 点击下载链接

## 🎯 优势

### 免费使用
- GitHub Actions对公开仓库免费
- 每月2000分钟构建时间

### 自动化
- 代码更新自动触发构建
- 无需本地环境配置

### 专业级
- 使用标准的CI/CD流程
- 生成可发布的APK

## 📞 技术支持

如果遇到问题：

1. **查看构建日志**
   - Actions页面有详细日志
   - 可以定位具体问题

2. **常见解决方案**
   - 重新触发构建
   - 检查代码完整性
   - 确认文件路径正确

## 🎉 成功标志

构建成功后，您将获得：

- ✅ 可安装的APK文件
- ✅ 自动版本号管理
- ✅ 完整的构建日志
- ✅ 专业的发布流程

---

**按照以上步骤，您就可以在GitHub上自动构建出《元素对战》的APK文件了！** 🎮

**预计15分钟内就能下载到可安装的游戏APK！** ⚡
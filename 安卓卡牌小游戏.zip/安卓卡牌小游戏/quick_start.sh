#!/bin/bash

# 元素对战 - 快速开始脚本
# 帮助用户快速设置GitHub自动构建

echo "🎮 元素对战 - 快速开始向导"
echo "=================================="
echo ""

# 检查是否有git
if ! command -v git &> /dev/null; then
    echo "⚠️  Git未安装，将使用手动上传方式"
    echo ""
    echo "📋 手动上传步骤："
    echo "1. 访问 https://github.com"
    echo "2. 创建新仓库 'element-battle-game'"
    echo "3. 将整个项目文件夹压缩成ZIP"
    echo "4. 上传到GitHub仓库"
    echo "5. 等待自动构建完成"
    echo "6. 下载生成的APK文件"
    echo ""
    echo "详细说明请查看: GITHUB_BUILD_GUIDE.md"
    exit 0
fi

echo "✅ 检测到Git环境"
echo ""

# 询问GitHub用户名
read -p "请输入您的GitHub用户名: " github_username
if [ -z "$github_username" ]; then
    echo "❌ 用户名不能为空"
    exit 1
fi

# 询问仓库名称
read -p "请输入仓库名称 (默认: element-battle-game): " repo_name
repo_name=${repo_name:-element-battle-game}

echo ""
echo "📋 配置信息："
echo "GitHub用户名: $github_username"
echo "仓库名称: $repo_name"
echo "仓库地址: https://github.com/$github_username/$repo_name"
echo ""

read -p "确认配置正确？(y/N): " -n 1 -r
echo
if [[ ! $REPLY =~ ^[Yy]$ ]]; then
    echo "操作已取消"
    exit 0
fi

echo ""
echo "🚀 开始设置Git仓库..."

# 初始化Git仓库
if [ ! -d ".git" ]; then
    git init
    echo "✅ Git仓库初始化完成"
else
    echo "✅ Git仓库已存在"
fi

# 添加所有文件
git add .
echo "✅ 文件添加完成"

# 提交
git commit -m "Initial commit: Element Battle Game

🎮 元素对战卡牌游戏
- 完整的Android项目
- Kotlin + Jetpack Compose
- 自动构建配置
- 详细文档

Features:
- 🔥💧🌍💨 四大元素相克系统
- 🤖 智能AI对手
- 🎨 现代化UI设计
- 🧪 全面测试覆盖
"

echo "✅ 代码提交完成"

# 设置远程仓库
git remote remove origin 2>/dev/null || true
git remote add origin "https://github.com/$github_username/$repo_name.git"
echo "✅ 远程仓库设置完成"

echo ""
echo "📤 准备推送到GitHub..."
echo ""
echo "⚠️  接下来需要您手动操作："
echo ""
echo "1. 在浏览器中访问: https://github.com/$github_username"
echo "2. 点击 'New repository' 创建新仓库"
echo "3. 仓库名称填写: $repo_name"
echo "4. 设置为 Public（免费用户）"
echo "5. 不要勾选 'Initialize with README'"
echo "6. 点击 'Create repository'"
echo ""
echo "7. 创建完成后，回到这里按任意键继续..."

read -p "按任意键继续..." -n 1 -r
echo ""

echo "🚀 推送代码到GitHub..."

# 推送代码
if git push -u origin main 2>/dev/null; then
    echo "✅ 代码推送成功！"
elif git push -u origin master 2>/dev/null; then
    echo "✅ 代码推送成功！"
else
    echo "❌ 推送失败，请检查："
    echo "1. 仓库是否已创建"
    echo "2. 用户名是否正确"
    echo "3. 是否有推送权限"
    echo ""
    echo "手动推送命令："
    echo "git push -u origin main"
    exit 1
fi

echo ""
echo "🎉 设置完成！"
echo ""
echo "📋 下一步操作："
echo "1. 访问: https://github.com/$github_username/$repo_name"
echo "2. 点击 'Actions' 标签查看构建进度"
echo "3. 等待构建完成（约10-15分钟）"
echo "4. 下载生成的APK文件"
echo ""
echo "📱 APK下载位置："
echo "- Actions页面的Artifacts部分"
echo "- Releases页面（如果构建成功）"
echo ""
echo "🎮 享受《元素对战》游戏！"
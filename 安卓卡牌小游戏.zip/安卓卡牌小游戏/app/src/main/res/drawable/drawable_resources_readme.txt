# Drawable资源说明

这个目录应该包含以下图片资源：

## 元素背景图片
- fire_background.xml - 火元素背景
- water_background.xml - 水元素背景
- earth_background.xml - 土元素背景
- wind_background.xml - 风元素背景

## UI组件图片
- card_background.xml - 卡牌背景
- button_background.xml - 按钮背景
- game_background.xml - 游戏背景

## 图标资源
- ic_launcher.xml - 应用图标
- ic_settings.xml - 设置图标
- ic_sound_on.xml - 音效开启图标
- ic_sound_off.xml - 音效关闭图标

## 创建方法
1. 使用Vector Drawable (推荐)
2. 使用PNG图片 (适用于复杂图像)
3. 使用Shape Drawable (适用于简单形状)

## 示例Vector Drawable (fire_background.xml):
```xml
<?xml version="1.0" encoding="utf-8"?>
<vector xmlns:android="http://schemas.android.com/apk/res/android"
    android:width="24dp"
    android:height="24dp"
    android:viewportWidth="24"
    android:viewportHeight="24">
    <path
        android:fillColor="#FF4444"
        android:pathData="M12,2C6.48,2 2,6.48 2,12s4.48,10 10,10 10,-4.48 10,-10S17.52,2 12,2z"/>
</vector>
```

## 注意事项
1. 使用适当的分辨率 (mdpi, hdpi, xhdpi, xxhdpi)
2. 保持文件大小合理
3. 使用Vector Drawable以支持不同屏幕密度
4. 确保图片有适当的版权许可
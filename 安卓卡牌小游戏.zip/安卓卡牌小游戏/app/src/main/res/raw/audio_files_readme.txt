# 音频文件说明

这个目录应该包含以下音频文件：

## 音效文件 (Sound Effects)
- card_play.wav - 出牌音效
- card_attack.wav - 卡牌攻击音效
- card_death.wav - 卡牌死亡音效
- player_damage.wav - 玩家受伤音效
- button_click.wav - 按钮点击音效
- game_win.wav - 游戏胜利音效
- game_lose.wav - 游戏失败音效
- turn_start.wav - 回合开始音效

## 背景音乐文件 (Background Music)
- menu_music.mp3 - 主菜单背景音乐
- battle_music.mp3 - 战斗背景音乐
- victory_music.mp3 - 胜利音乐
- defeat_music.mp3 - 失败音乐

## 音频格式要求
- 音效文件：WAV格式，16-bit，44.1kHz，单声道或立体声
- 背景音乐：MP3格式，128kbps或更高，立体声
- 文件大小：音效文件 < 100KB，背景音乐 < 2MB

## 获取音频资源
可以从以下网站获取免费的游戏音频：
- Freesound.org
- Zapsplat.com
- Adobe Audition内置音效库
- Unity Asset Store (免费音频包)

## 注意事项
1. 确保音频文件有适当的版权许可
2. 音效应该简短而清晰
3. 背景音乐应该能够无缝循环
4. 测试音频在不同设备上的播放效果
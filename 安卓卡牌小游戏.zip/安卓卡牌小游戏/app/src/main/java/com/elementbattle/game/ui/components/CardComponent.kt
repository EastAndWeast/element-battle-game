package com.elementbattle.game.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.elementbattle.game.domain.entities.Card
import com.elementbattle.game.domain.entities.Element

@Composable
fun CardComponent(
    card: Card,
    isPlayable: Boolean,
    isSelected: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val elementColor = when (card.element) {
        Element.FIRE -> Color(0xFFFF4444)
        Element.WATER -> Color(0xFF4488FF)
        Element.EARTH -> Color(0xFF8B4513)
        Element.WIND -> Color(0xFF32CD32)
    }

    val alpha = if (isPlayable) 1.0f else 0.6f
    val borderColor = if (isSelected) Color.Yellow else elementColor
    val borderWidth = if (isSelected) 3.dp else 1.dp

    Card(
        modifier = modifier
            .alpha(alpha)
            .border(borderWidth, borderColor, RoundedCornerShape(8.dp))
            .clickable(enabled = isPlayable) { onClick() },
        shape = RoundedCornerShape(8.dp),
        colors = CardDefaults.cardColors(
            containerColor = Color(0xFF2A2A3E)
        )
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(4.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // 法力消耗和元素图标
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                // 法力消耗
                Box(
                    modifier = Modifier
                        .size(20.dp)
                        .background(
                            color = Color(0xFF4A90E2),
                            shape = RoundedCornerShape(10.dp)
                        ),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = "${card.manaCost}",
                        color = Color.White,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold
                    )
                }

                // 元素图标
                Text(
                    text = card.element.emoji,
                    fontSize = 16.sp
                )
            }

            Spacer(modifier = Modifier.height(4.dp))

            // 卡牌名称
            Text(
                text = card.name,
                color = Color.White,
                fontSize = 10.sp,
                fontWeight = FontWeight.Bold,
                textAlign = TextAlign.Center,
                maxLines = 2
            )

            Spacer(modifier = Modifier.weight(1f))

            // 攻击力和生命值
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                // 攻击力
                Box(
                    modifier = Modifier
                        .size(18.dp)
                        .background(
                            color = Color(0xFFFF6B6B),
                            shape = RoundedCornerShape(9.dp)
                        ),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = "${card.currentAttack}",
                        color = Color.White,
                        fontSize = 9.sp,
                        fontWeight = FontWeight.Bold
                    )
                }

                // 生命值
                Box(
                    modifier = Modifier
                        .size(18.dp)
                        .background(
                            color = Color(0xFF4ECDC4),
                            shape = RoundedCornerShape(9.dp)
                        ),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = "${card.currentHealth}",
                        color = Color.White,
                        fontSize = 9.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }
    }
}
package com.elementbattle.game.data.audio

import android.content.Context
import android.media.AudioAttributes
import android.media.MediaPlayer
import android.media.SoundPool
import android.util.Log
import com.elementbattle.game.R
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class AudioManager @Inject constructor(
    @ApplicationContext private val context: Context
) {
    private var soundPool: SoundPool? = null
    private var backgroundMusicPlayer: MediaPlayer? = null
    private val soundMap = mutableMapOf<SoundEffect, Int>()

    private var isSoundEnabled = true
    private var isMusicEnabled = true
    private var musicVolume = 0.5f
    private var soundVolume = 1.0f

    private val coroutineScope = CoroutineScope(Dispatchers.IO)

    init {
        initializeSoundPool()
        loadSounds()
    }

    private fun initializeSoundPool() {
        val audioAttributes = AudioAttributes.Builder()
            .setUsage(AudioAttributes.USAGE_GAME)
            .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
            .build()

        soundPool = SoundPool.Builder()
            .setMaxStreams(10)
            .setAudioAttributes(audioAttributes)
            .build()
    }

    private fun loadSounds() {
        coroutineScope.launch {
            try {
                soundPool?.let { pool ->
                    // 注意：这些音频文件需要放在 res/raw/ 目录下
                    // 这里使用占位符，实际项目中需要真实的音频文件
                    soundMap[SoundEffect.CARD_PLAY] = pool.load(context, R.raw.card_play, 1)
                    soundMap[SoundEffect.CARD_ATTACK] = pool.load(context, R.raw.card_attack, 1)
                    soundMap[SoundEffect.CARD_DEATH] = pool.load(context, R.raw.card_death, 1)
                    soundMap[SoundEffect.PLAYER_DAMAGE] = pool.load(context, R.raw.player_damage, 1)
                    soundMap[SoundEffect.BUTTON_CLICK] = pool.load(context, R.raw.button_click, 1)
                    soundMap[SoundEffect.GAME_WIN] = pool.load(context, R.raw.game_win, 1)
                    soundMap[SoundEffect.GAME_LOSE] = pool.load(context, R.raw.game_lose, 1)
                    soundMap[SoundEffect.TURN_START] = pool.load(context, R.raw.turn_start, 1)
                }
            } catch (e: Exception) {
                Log.e("AudioManager", "Error loading sounds: ${e.message}")
            }
        }
    }

    fun playSound(effect: SoundEffect) {
        if (!isSoundEnabled) return

        coroutineScope.launch {
            try {
                soundMap[effect]?.let { soundId ->
                    soundPool?.play(soundId, soundVolume, soundVolume, 1, 0, 1.0f)
                }
            } catch (e: Exception) {
                Log.e("AudioManager", "Error playing sound: ${e.message}")
            }
        }
    }

    fun startBackgroundMusic(musicType: BackgroundMusic) {
        if (!isMusicEnabled) return

        stopBackgroundMusic()

        try {
            val resourceId = when (musicType) {
                BackgroundMusic.MAIN_MENU -> R.raw.menu_music
                BackgroundMusic.GAME_BATTLE -> R.raw.battle_music
                BackgroundMusic.VICTORY -> R.raw.victory_music
                BackgroundMusic.DEFEAT -> R.raw.defeat_music
            }

            backgroundMusicPlayer = MediaPlayer.create(context, resourceId)?.apply {
                isLooping = true
                setVolume(musicVolume, musicVolume)
                start()
            }
        } catch (e: Exception) {
            Log.e("AudioManager", "Error starting background music: ${e.message}")
        }
    }

    fun stopBackgroundMusic() {
        backgroundMusicPlayer?.let { player ->
            if (player.isPlaying) {
                player.stop()
            }
            player.release()
            backgroundMusicPlayer = null
        }
    }

    fun pauseBackgroundMusic() {
        backgroundMusicPlayer?.let { player ->
            if (player.isPlaying) {
                player.pause()
            }
        }
    }

    fun resumeBackgroundMusic() {
        backgroundMusicPlayer?.let { player ->
            if (!player.isPlaying) {
                player.start()
            }
        }
    }

    fun setSoundEnabled(enabled: Boolean) {
        isSoundEnabled = enabled
    }

    fun setMusicEnabled(enabled: Boolean) {
        isMusicEnabled = enabled
        if (!enabled) {
            stopBackgroundMusic()
        }
    }

    fun setSoundVolume(volume: Float) {
        soundVolume = volume.coerceIn(0f, 1f)
    }

    fun setMusicVolume(volume: Float) {
        musicVolume = volume.coerceIn(0f, 1f)
        backgroundMusicPlayer?.setVolume(musicVolume, musicVolume)
    }

    fun release() {
        stopBackgroundMusic()
        soundPool?.release()
        soundPool = null
    }
}

enum class SoundEffect {
    CARD_PLAY,
    CARD_ATTACK,
    CARD_DEATH,
    PLAYER_DAMAGE,
    BUTTON_CLICK,
    GAME_WIN,
    GAME_LOSE,
    TURN_START
}

enum class BackgroundMusic {
    MAIN_MENU,
    GAME_BATTLE,
    VICTORY,
    DEFEAT
}
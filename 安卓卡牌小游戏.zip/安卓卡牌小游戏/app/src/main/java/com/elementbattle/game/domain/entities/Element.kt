package com.elementbattle.game.domain.entities

enum class Element(
    val displayName: String,
    val emoji: String,
    val colorHex: String
) {
    FIRE("火", "🔥", "#FF4444"),
    WATER("水", "💧", "#4488FF"),
    EARTH("土", "🌍", "#8B4513"),
    WIND("风", "💨", "#32CD32");

    /**
     * 获取克制的元素
     * 火克风，风克土，土克水，水克火
     */
    fun getAdvantageAgainst(): Element = when (this) {
        FIRE -> WIND
        WIND -> EARTH
        EARTH -> WATER
        WATER -> FIRE
    }

    /**
     * 获取被克制的元素
     */
    fun getDisadvantageAgainst(): Element = when (this) {
        FIRE -> WATER
        WATER -> EARTH
        EARTH -> WIND
        WIND -> FIRE
    }

    /**
     * 计算对目标元素的伤害倍率
     */
    fun getDamageMultiplier(target: Element): Float = when {
        getAdvantageAgainst() == target -> 1.5f // 克制时伤害+50%
        getDisadvantageAgainst() == target -> 0.75f // 被克制时伤害-25%
        else -> 1.0f // 相同或无关系时正常伤害
    }
}
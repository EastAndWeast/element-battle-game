package com.elementbattle.game.ui.navigation

import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.elementbattle.game.domain.entities.GameState
import com.elementbattle.game.ui.screens.GameScreen
import com.elementbattle.game.ui.screens.GameOverScreen
import com.elementbattle.game.ui.screens.MainMenuScreen
import com.elementbattle.game.ui.screens.SettingsScreen
import com.elementbattle.game.ui.viewmodels.GameViewModel

@Composable
fun ElementBattleNavigation() {
    val navController = rememberNavController()
    val gameViewModel: GameViewModel = hiltViewModel()
    val gameState by gameViewModel.gameState.collectAsState()

    NavHost(
        navController = navController,
        startDestination = "main_menu"
    ) {
        composable("main_menu") {
            MainMenuScreen(
                onStartGame = {
                    gameViewModel.startNewGame()
                    navController.navigate("game") {
                        popUpTo("main_menu") { inclusive = false }
                    }
                },
                onSettings = {
                    navController.navigate("settings")
                },
                onExit = {
                    // 处理退出逻辑
                }
            )
        }

        composable("game") {
            when (val state = gameState) {
                is GameState.Playing -> {
                    GameScreen(
                        gameState = state,
                        onPlayCard = gameViewModel::playCard,
                        onAttackCard = gameViewModel::attackCard,
                        onAttackPlayer = gameViewModel::attackPlayer,
                        onEndTurn = gameViewModel::endTurn,
                        onBackToMenu = {
                            navController.navigate("main_menu") {
                                popUpTo("game") { inclusive = true }
                            }
                        }
                    )
                }
                is GameState.GameOver -> {
                    GameOverScreen(
                        gameOverState = state,
                        onPlayAgain = {
                            gameViewModel.startNewGame()
                        },
                        onBackToMenu = {
                            navController.navigate("main_menu") {
                                popUpTo("game") { inclusive = true }
                            }
                        }
                    )
                }
                else -> {
                    // 加载状态或其他状态
                    MainMenuScreen(
                        onStartGame = {
                            gameViewModel.startNewGame()
                        },
                        onSettings = {
                            navController.navigate("settings")
                        },
                        onExit = {}
                    )
                }
            }
        }

        composable("settings") {
            SettingsScreen(
                onBack = {
                    navController.popBackStack()
                }
            )
        }
    }
}
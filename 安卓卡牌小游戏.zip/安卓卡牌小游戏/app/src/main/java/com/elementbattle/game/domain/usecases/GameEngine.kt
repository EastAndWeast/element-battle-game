package com.elementbattle.game.domain.usecases

import com.elementbattle.game.domain.entities.*
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class GameEngine @Inject constructor(
    private val cardFactory: CardFactory,
    private val aiStrategy: AIStrategy
) {

    /**
     * 开始新游戏
     */
    fun startNewGame(): GameState.Playing {
        val playerDeck = cardFactory.createStarterDeck()
        val enemyDeck = cardFactory.createStarterDeck()

        val player = Player(
            id = "player",
            name = "玩家",
            deck = playerDeck.shuffled(),
            isAI = false
        ).let { p ->
            // 抽初始手牌
            (1..Player.INITIAL_HAND_SIZE).fold(p) { acc, _ -> acc.drawCard() }
        }

        val enemy = Player(
            id = "enemy",
            name = "AI对手",
            deck = enemyDeck.shuffled(),
            isAI = true
        ).let { e ->
            // 抽初始手牌
            (1..Player.INITIAL_HAND_SIZE).fold(e) { acc, _ -> acc.drawCard() }
        }

        return GameState.Playing(
            player = player,
            enemy = enemy,
            currentTurn = PlayerType.HUMAN
        )
    }

    /**
     * 玩家出牌
     */
    fun playCard(gameState: GameState.Playing, card: Card): GameState {
        if (gameState.currentTurn != PlayerType.HUMAN) return gameState
        if (!gameState.player.canPlayCard(card)) return gameState

        val newPlayer = gameState.player.playCard(card)
        val newGameState = gameState.copy(
            player = newPlayer,
            lastAction = GameAction.PlayCard(card, PlayerType.HUMAN)
        )

        return checkGameOver(newGameState)
    }

    /**
     * 卡牌攻击卡牌
     */
    fun attackCard(gameState: GameState.Playing, attacker: Card, target: Card): GameState {
        if (!attacker.canAttack) return gameState

        val (newAttacker, newTarget) = attacker.attackCard(target)

        val newGameState = if (gameState.currentTurn == PlayerType.HUMAN) {
            gameState.copy(
                player = gameState.player.updateFieldCard(attacker, newAttacker),
                enemy = gameState.enemy.updateFieldCard(target, newTarget),
                lastAction = GameAction.AttackCard(attacker, target, PlayerType.HUMAN)
            )
        } else {
            gameState.copy(
                enemy = gameState.enemy.updateFieldCard(attacker, newAttacker),
                player = gameState.player.updateFieldCard(target, newTarget),
                lastAction = GameAction.AttackCard(attacker, target, PlayerType.AI)
            )
        }

        return checkGameOver(newGameState.copy(
            player = newGameState.player.removeDeadCards(),
            enemy = newGameState.enemy.removeDeadCards()
        ))
    }

    /**
     * 卡牌攻击玩家
     */
    fun attackPlayer(gameState: GameState.Playing, attacker: Card, targetPlayer: PlayerType): GameState {
        if (!attacker.canAttack) return gameState

        val damage = attacker.currentAttack
        val newGameState = when (targetPlayer) {
            PlayerType.HUMAN -> gameState.copy(
                player = gameState.player.takeDamage(damage),
                enemy = gameState.enemy.updateFieldCard(attacker, attacker.copy(isExhausted = true)),
                lastAction = GameAction.AttackPlayer(attacker, PlayerType.HUMAN)
            )
            PlayerType.AI -> gameState.copy(
                enemy = gameState.enemy.takeDamage(damage),
                player = gameState.player.updateFieldCard(attacker, attacker.copy(isExhausted = true)),
                lastAction = GameAction.AttackPlayer(attacker, PlayerType.AI)
            )
        }

        return checkGameOver(newGameState)
    }

    /**
     * 结束回合
     */
    fun endTurn(gameState: GameState.Playing): GameState {
        val nextTurn = if (gameState.currentTurn == PlayerType.HUMAN) PlayerType.AI else PlayerType.HUMAN
        val newTurnNumber = if (nextTurn == PlayerType.HUMAN) gameState.turnNumber + 1 else gameState.turnNumber

        val newGameState = gameState.copy(
            currentTurn = nextTurn,
            turnNumber = newTurnNumber,
            gamePhase = GamePhase.MAIN,
            selectedCard = null,
            selectedTarget = null,
            lastAction = GameAction.EndTurn(gameState.currentTurn)
        )

        // 开始新回合
        val updatedGameState = if (nextTurn == PlayerType.HUMAN) {
            newGameState.copy(player = newGameState.player.startTurn(newTurnNumber))
        } else {
            newGameState.copy(enemy = newGameState.enemy.startTurn(newTurnNumber))
        }

        return checkGameOver(updatedGameState)
    }

    /**
     * AI回合
     */
    suspend fun processAITurn(gameState: GameState.Playing): GameState {
        if (gameState.currentTurn != PlayerType.AI) return gameState

        var currentState = gameState

        // AI出牌阶段
        while (true) {
            val cardToPlay = aiStrategy.selectCardToPlay(
                currentState.enemy.hand,
                currentState.enemy.field,
                currentState.player.field,
                currentState.enemy.mana
            )

            if (cardToPlay == null) break

            val newEnemy = currentState.enemy.playCard(cardToPlay)
            currentState = currentState.copy(
                enemy = newEnemy,
                lastAction = GameAction.PlayCard(cardToPlay, PlayerType.AI)
            )
        }

        // AI攻击阶段
        val attackableCards = currentState.enemy.getAttackableCards()
        for (attacker in attackableCards) {
            val target = aiStrategy.selectAttackTarget(
                attacker,
                currentState.player.field,
                currentState.player
            )

            when (target) {
                is AITarget.Card -> {
                    currentState = attackCard(currentState, attacker, target.card) as GameState.Playing
                }
                is AITarget.Player -> {
                    currentState = attackPlayer(currentState, attacker, PlayerType.HUMAN) as GameState.Playing
                }
                AITarget.None -> {
                    // 不攻击
                }
            }
        }

        // AI结束回合
        return endTurn(currentState)
    }

    /**
     * 检查游戏是否结束
     */
    private fun checkGameOver(gameState: GameState.Playing): GameState {
        return when {
            !gameState.player.isAlive -> GameState.GameOver(
                winner = PlayerType.AI,
                finalPlayer = gameState.player,
                finalEnemy = gameState.enemy,
                reason = GameOverReason.PLAYER_DEFEATED
            )
            !gameState.enemy.isAlive -> GameState.GameOver(
                winner = PlayerType.HUMAN,
                finalPlayer = gameState.player,
                finalEnemy = gameState.enemy,
                reason = GameOverReason.ENEMY_DEFEATED
            )
            else -> gameState
        }
    }
}
package com.elementbattle.game.ui.viewmodels

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.elementbattle.game.domain.entities.*
import com.elementbattle.game.domain.usecases.GameEngine
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class GameViewModel @Inject constructor(
    private val gameEngine: GameEngine
) : ViewModel() {

    private val _gameState = MutableStateFlow<GameState>(GameState.MainMenu)
    val gameState: StateFlow<GameState> = _gameState.asStateFlow()

    private val _isLoading = MutableStateFlow(false)
    val isLoading: StateFlow<Boolean> = _isLoading.asStateFlow()

    private val _selectedCard = MutableStateFlow<Card?>(null)
    val selectedCard: StateFlow<Card?> = _selectedCard.asStateFlow()

    /**
     * 开始新游戏
     */
    fun startNewGame() {
        viewModelScope.launch {
            _isLoading.value = true
            try {
                val newGameState = gameEngine.startNewGame()
                _gameState.value = newGameState
                _selectedCard.value = null
            } catch (e: Exception) {
                // 处理错误
                _gameState.value = GameState.MainMenu
            } finally {
                _isLoading.value = false
            }
        }
    }

    /**
     * 玩家出牌
     */
    fun playCard(card: Card) {
        val currentState = _gameState.value
        if (currentState !is GameState.Playing) return

        viewModelScope.launch {
            val newState = gameEngine.playCard(currentState, card)
            _gameState.value = newState
            _selectedCard.value = null

            // 如果还在游戏中且轮到AI，处理AI回合
            if (newState is GameState.Playing && newState.currentTurn == PlayerType.AI) {
                processAITurn()
            }
        }
    }

    /**
     * 卡牌攻击卡牌
     */
    fun attackCard(attacker: Card, target: Card) {
        val currentState = _gameState.value
        if (currentState !is GameState.Playing) return

        viewModelScope.launch {
            val newState = gameEngine.attackCard(currentState, attacker, target)
            _gameState.value = newState
            _selectedCard.value = null
        }
    }

    /**
     * 卡牌攻击玩家
     */
    fun attackPlayer(attacker: Card, targetPlayer: PlayerType) {
        val currentState = _gameState.value
        if (currentState !is GameState.Playing) return

        viewModelScope.launch {
            val newState = gameEngine.attackPlayer(currentState, attacker, targetPlayer)
            _gameState.value = newState
            _selectedCard.value = null
        }
    }

    /**
     * 结束回合
     */
    fun endTurn() {
        val currentState = _gameState.value
        if (currentState !is GameState.Playing) return

        viewModelScope.launch {
            val newState = gameEngine.endTurn(currentState)
            _gameState.value = newState
            _selectedCard.value = null

            // 如果轮到AI，处理AI回合
            if (newState is GameState.Playing && newState.currentTurn == PlayerType.AI) {
                processAITurn()
            }
        }
    }

    /**
     * 选择卡牌
     */
    fun selectCard(card: Card?) {
        _selectedCard.value = card
    }

    /**
     * 返回主菜单
     */
    fun backToMainMenu() {
        _gameState.value = GameState.MainMenu
        _selectedCard.value = null
    }

    /**
     * 处理AI回合
     */
    private suspend fun processAITurn() {
        val currentState = _gameState.value
        if (currentState !is GameState.Playing || currentState.currentTurn != PlayerType.AI) return

        // 添加延迟让玩家看到AI的动作
        delay(1000)

        try {
            val newState = gameEngine.processAITurn(currentState)
            _gameState.value = newState
        } catch (e: Exception) {
            // 处理AI错误，强制结束AI回合
            val fallbackState = gameEngine.endTurn(currentState)
            _gameState.value = fallbackState
        }
    }

    /**
     * 重新开始游戏
     */
    fun restartGame() {
        startNewGame()
    }

    /**
     * 暂停游戏
     */
    fun pauseGame() {
        // 实现暂停逻辑
    }

    /**
     * 恢复游戏
     */
    fun resumeGame() {
        // 实现恢复逻辑
    }
}
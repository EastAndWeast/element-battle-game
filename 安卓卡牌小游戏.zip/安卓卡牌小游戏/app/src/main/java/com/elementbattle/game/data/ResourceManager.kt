package com.elementbattle.game.data

import android.content.Context
import android.graphics.drawable.Drawable
import androidx.core.content.ContextCompat
import com.elementbattle.game.R
import com.elementbattle.game.domain.entities.Element
import dagger.hilt.android.qualifiers.ApplicationContext
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class ResourceManager @Inject constructor(
    @ApplicationContext private val context: Context
) {

    /**
     * 获取元素对应的颜色资源ID
     */
    fun getElementColor(element: Element): Int {
        return when (element) {
            Element.FIRE -> android.graphics.Color.parseColor("#FF4444")
            Element.WATER -> android.graphics.Color.parseColor("#4488FF")
            Element.EARTH -> android.graphics.Color.parseColor("#8B4513")
            Element.WIND -> android.graphics.Color.parseColor("#32CD32")
        }
    }

    /**
     * 获取元素对应的图标
     */
    fun getElementIcon(element: Element): String {
        return when (element) {
            Element.FIRE -> "🔥"
            Element.WATER -> "💧"
            Element.EARTH -> "🌍"
            Element.WIND -> "💨"
        }
    }

    /**
     * 获取元素对应的背景drawable
     */
    fun getElementBackground(element: Element): Drawable? {
        val resourceId = when (element) {
            Element.FIRE -> R.drawable.fire_background
            Element.WATER -> R.drawable.water_background
            Element.EARTH -> R.drawable.earth_background
            Element.WIND -> R.drawable.wind_background
        }
        return try {
            ContextCompat.getDrawable(context, resourceId)
        } catch (e: Exception) {
            // 如果资源不存在，返回默认背景
            null
        }
    }

    /**
     * 获取卡牌稀有度对应的边框颜色
     */
    fun getRarityBorderColor(rarity: com.elementbattle.game.domain.entities.CardRarity): Int {
        return when (rarity) {
            com.elementbattle.game.domain.entities.CardRarity.COMMON ->
                android.graphics.Color.parseColor("#CCCCCC")
            com.elementbattle.game.domain.entities.CardRarity.RARE ->
                android.graphics.Color.parseColor("#4CAF50")
            com.elementbattle.game.domain.entities.CardRarity.EPIC ->
                android.graphics.Color.parseColor("#9C27B0")
            com.elementbattle.game.domain.entities.CardRarity.LEGENDARY ->
                android.graphics.Color.parseColor("#FF9800")
        }
    }

    /**
     * 获取字符串资源
     */
    fun getString(resourceId: Int): String {
        return context.getString(resourceId)
    }

    /**
     * 获取字符串资源（带参数）
     */
    fun getString(resourceId: Int, vararg formatArgs: Any): String {
        return context.getString(resourceId, *formatArgs)
    }

    /**
     * 获取颜色资源
     */
    fun getColor(resourceId: Int): Int {
        return ContextCompat.getColor(context, resourceId)
    }

    /**
     * 获取drawable资源
     */
    fun getDrawable(resourceId: Int): Drawable? {
        return ContextCompat.getDrawable(context, resourceId)
    }

    /**
     * 预加载资源
     */
    fun preloadResources() {
        // 预加载常用的drawable资源
        Element.values().forEach { element ->
            getElementBackground(element)
        }

        // 预加载其他常用资源
        try {
            getDrawable(R.drawable.card_background)
            getDrawable(R.drawable.button_background)
        } catch (e: Exception) {
            // 忽略不存在的资源
        }
    }

    /**
     * 清理资源缓存
     */
    fun clearCache() {
        // 如果有缓存机制，在这里清理
    }
}
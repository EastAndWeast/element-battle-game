package com.elementbattle.game.domain.usecases

import com.elementbattle.game.domain.entities.*
import javax.inject.Inject
import javax.inject.Singleton
import kotlin.random.Random

interface AIStrategy {
    suspend fun selectCardToPlay(
        hand: List<Card>,
        field: List<Card>,
        enemyField: List<Card>,
        availableMana: Int
    ): Card?

    suspend fun selectAttackTarget(
        attacker: Card,
        enemyField: List<Card>,
        enemyPlayer: Player
    ): AITarget
}

sealed class AITarget {
    data class Card(val card: com.elementbattle.game.domain.entities.Card) : AITarget()
    object Player : AITarget()
    object None : AITarget()
}

@Singleton
class SimpleAIStrategy @Inject constructor() : AIStrategy {

    override suspend fun selectCardToPlay(
        hand: List<Card>,
        field: List<Card>,
        enemyField: List<Card>,
        availableMana: Int
    ): Card? {
        // 简单策略：优先出费用最高但不超过法力值的牌
        val playableCards = hand.filter { it.manaCost <= availableMana }
        if (playableCards.isEmpty()) return null

        // 如果场上没有卡牌，优先出攻击力高的
        if (field.isEmpty()) {
            return playableCards.maxByOrNull { it.baseAttack }
        }

        // 如果敌方场上有卡牌，考虑元素克制关系
        if (enemyField.isNotEmpty()) {
            val advantageousCards = playableCards.filter { card ->
                enemyField.any { enemy ->
                    card.element.getDamageMultiplier(enemy.element) > 1.0f
                }
            }
            if (advantageousCards.isNotEmpty()) {
                return advantageousCards.maxByOrNull { it.manaCost }
            }
        }

        // 默认选择费用最高的牌
        return playableCards.maxByOrNull { it.manaCost }
    }

    override suspend fun selectAttackTarget(
        attacker: Card,
        enemyField: List<Card>,
        enemyPlayer: Player
    ): AITarget {
        if (enemyField.isEmpty()) {
            // 如果敌方场上没有卡牌，直接攻击玩家
            return AITarget.Player
        }

        // 寻找可以一击击杀的目标
        val killableTargets = enemyField.filter { target ->
            val damage = (attacker.currentAttack * attacker.element.getDamageMultiplier(target.element)).toInt()
            damage >= target.currentHealth
        }

        if (killableTargets.isNotEmpty()) {
            // 优先击杀攻击力最高的
            return AITarget.Card(killableTargets.maxByOrNull { it.currentAttack }!!)
        }

        // 寻找有元素优势的目标
        val advantageousTargets = enemyField.filter { target ->
            attacker.element.getDamageMultiplier(target.element) > 1.0f
        }

        if (advantageousTargets.isNotEmpty()) {
            // 攻击生命值最低的有优势目标
            return AITarget.Card(advantageousTargets.minByOrNull { it.currentHealth }!!)
        }

        // 如果没有特别的目标，随机选择或攻击玩家
        return if (Random.nextFloat() < 0.7f && enemyField.isNotEmpty()) {
            // 70%概率攻击场上生命值最低的卡牌
            AITarget.Card(enemyField.minByOrNull { it.currentHealth }!!)
        } else {
            // 30%概率直接攻击玩家
            AITarget.Player
        }
    }
}

@Singleton
class AggressiveAIStrategy @Inject constructor() : AIStrategy {

    override suspend fun selectCardToPlay(
        hand: List<Card>,
        field: List<Card>,
        enemyField: List<Card>,
        availableMana: Int
    ): Card? {
        // 激进策略：优先出攻击力高的牌
        val playableCards = hand.filter { it.manaCost <= availableMana }
        return playableCards.maxByOrNull { it.baseAttack }
    }

    override suspend fun selectAttackTarget(
        attacker: Card,
        enemyField: List<Card>,
        enemyPlayer: Player
    ): AITarget {
        // 激进策略：优先攻击玩家
        return if (enemyField.isEmpty() || Random.nextFloat() < 0.6f) {
            AITarget.Player
        } else {
            // 攻击生命值最低的敌方卡牌
            AITarget.Card(enemyField.minByOrNull { it.currentHealth }!!)
        }
    }
}

@Singleton
class DefensiveAIStrategy @Inject constructor() : AIStrategy {

    override suspend fun selectCardToPlay(
        hand: List<Card>,
        field: List<Card>,
        enemyField: List<Card>,
        availableMana: Int
    ): Card? {
        // 防守策略：优先出生命值高的牌
        val playableCards = hand.filter { it.manaCost <= availableMana }
        return playableCards.maxByOrNull { it.baseHealth }
    }

    override suspend fun selectAttackTarget(
        attacker: Card,
        enemyField: List<Card>,
        enemyPlayer: Player
    ): AITarget {
        // 防守策略：优先清理敌方场上的威胁
        if (enemyField.isEmpty()) return AITarget.Player

        // 优先攻击攻击力最高的敌方卡牌
        return AITarget.Card(enemyField.maxByOrNull { it.currentAttack }!!)
    }
}
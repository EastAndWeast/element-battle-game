package com.elementbattle.game.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.elementbattle.game.R
import com.elementbattle.game.domain.entities.*
import com.elementbattle.game.ui.components.CardComponent
import com.elementbattle.game.ui.components.PlayerInfoComponent

@Composable
fun GameScreen(
    gameState: GameState.Playing,
    onPlayCard: (Card) -> Unit,
    onAttackCard: (Card, Card) -> Unit,
    onAttackPlayer: (Card, PlayerType) -> Unit,
    onEndTurn: () -> Unit,
    onBackToMenu: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF1A1A2E))
            .padding(8.dp)
    ) {
        // 敌方信息
        PlayerInfoComponent(
            player = gameState.enemy,
            isCurrentPlayer = gameState.currentTurn == PlayerType.AI,
            modifier = Modifier.fillMaxWidth()
        )

        // 敌方场上卡牌
        LazyRow(
            modifier = Modifier
                .fillMaxWidth()
                .height(120.dp)
                .padding(vertical = 8.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            items(gameState.enemy.field) { card ->
                CardComponent(
                    card = card,
                    isPlayable = false,
                    isSelected = false,
                    onClick = { /* 敌方卡牌点击逻辑 */ },
                    modifier = Modifier.size(80.dp, 120.dp)
                )
            }
        }

        Spacer(modifier = Modifier.weight(1f))

        // 玩家场上卡牌
        LazyRow(
            modifier = Modifier
                .fillMaxWidth()
                .height(120.dp)
                .padding(vertical = 8.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            items(gameState.player.field) { card ->
                CardComponent(
                    card = card,
                    isPlayable = card.canAttack && gameState.currentTurn == PlayerType.HUMAN,
                    isSelected = false,
                    onClick = { /* 玩家场上卡牌点击逻辑 */ },
                    modifier = Modifier.size(80.dp, 120.dp)
                )
            }
        }

        // 玩家信息
        PlayerInfoComponent(
            player = gameState.player,
            isCurrentPlayer = gameState.currentTurn == PlayerType.HUMAN,
            modifier = Modifier.fillMaxWidth()
        )

        // 玩家手牌
        LazyRow(
            modifier = Modifier
                .fillMaxWidth()
                .height(140.dp)
                .padding(vertical = 8.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            items(gameState.player.hand) { card ->
                CardComponent(
                    card = card,
                    isPlayable = gameState.player.canPlayCard(card) &&
                                gameState.currentTurn == PlayerType.HUMAN,
                    isSelected = false,
                    onClick = { onPlayCard(card) },
                    modifier = Modifier.size(100.dp, 140.dp)
                )
            }
        }

        // 控制按钮
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(8.dp),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Button(
                onClick = onBackToMenu,
                colors = ButtonDefaults.buttonColors(
                    containerColor = Color(0xFF666666)
                )
            ) {
                Text("返回菜单")
            }

            if (gameState.currentTurn == PlayerType.HUMAN) {
                Button(
                    onClick = onEndTurn,
                    colors = ButtonDefaults.buttonColors(
                        containerColor = Color(0xFF4CAF50)
                    )
                ) {
                    Text(stringResource(R.string.end_turn))
                }
            } else {
                Text(
                    text = "AI回合中...",
                    style = MaterialTheme.typography.bodyLarge.copy(
                        color = Color.White,
                        fontWeight = FontWeight.Bold
                    )
                )
            }
        }
    }
}
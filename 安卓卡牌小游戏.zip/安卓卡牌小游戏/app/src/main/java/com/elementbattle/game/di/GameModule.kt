package com.elementbattle.game.di

import com.elementbattle.game.domain.usecases.AIStrategy
import com.elementbattle.game.domain.usecases.SimpleAIStrategy
import dagger.Binds
import dagger.Module
import dagger.hilt.InstallIn
import dagger.hilt.components.SingletonComponent
import javax.inject.Singleton

@Module
@InstallIn(SingletonComponent::class)
abstract class GameModule {

    @Binds
    @Singleton
    abstract fun bindAIStrategy(
        simpleAIStrategy: SimpleAIStrategy
    ): AIStrategy
}
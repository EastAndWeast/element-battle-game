package com.elementbattle.game.domain.usecases

import com.elementbattle.game.domain.entities.*
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class CardFactory @Inject constructor() {

    /**
     * 创建新手卡组
     */
    fun createStarterDeck(): List<Card> {
        return listOf(
            // 火元素卡牌
            createCard("火焰精灵", Element.FIRE, 2, 1, 1, "基础的火元素生物"),
            createCard("烈焰战士", Element.FIRE, 3, 2, 2, "勇猛的火焰战士"),
            createCard("火球术", Element.FIRE, 4, 1, 3, "强力的火焰法术"),
            createCard("炎魔", Element.FIRE, 5, 4, 4, "强大的火元素恶魔"),
            createCard("凤凰", Element.FIRE, 6, 5, 5, "传说中的不死鸟"),

            // 水元素卡牌
            createCard("水滴精灵", Element.WATER, 1, 3, 1, "灵活的水元素生物"),
            createCard("海浪战士", Element.WATER, 2, 3, 2, "来自深海的战士"),
            createCard("冰霜法术", Element.WATER, 3, 2, 3, "冰冷的水元素法术"),
            createCard("海妖", Element.WATER, 4, 5, 4, "美丽而危险的海洋生物"),
            createCard("海神", Element.WATER, 5, 6, 5, "掌控海洋的神祇"),

            // 土元素卡牌
            createCard("岩石精灵", Element.EARTH, 1, 4, 1, "坚硬的土元素生物"),
            createCard("石头巨人", Element.EARTH, 3, 5, 3, "巨大的岩石生物"),
            createCard("地震术", Element.EARTH, 2, 1, 2, "撼动大地的法术"),
            createCard("山岭巨龙", Element.EARTH, 6, 7, 5, "古老的土元素巨龙"),
            createCard("大地之母", Element.EARTH, 4, 6, 4, "孕育万物的大地女神"),

            // 风元素卡牌
            createCard("风之精灵", Element.WIND, 3, 1, 1, "迅捷的风元素生物"),
            createCard("暴风战士", Element.WIND, 4, 2, 2, "驾驭风暴的战士"),
            createCard("龙卷风", Element.WIND, 5, 1, 3, "毁灭性的风暴法术"),
            createCard("风神", Element.WIND, 5, 3, 4, "掌控天空的神祇"),
            createCard("雷鸟", Element.WIND, 6, 4, 5, "翱翔天际的神鸟")
        )
    }

    /**
     * 创建所有卡牌
     */
    fun createAllCards(): List<Card> {
        return createStarterDeck() + createAdvancedCards()
    }

    /**
     * 创建高级卡牌
     */
    private fun createAdvancedCards(): List<Card> {
        return listOf(
            // 稀有火元素卡牌
            createCard("烈焰君主", Element.FIRE, 7, 6, 6, "火元素的统治者", CardRarity.RARE),
            createCard("太阳神", Element.FIRE, 8, 8, 7, "光明与火焰的神祇", CardRarity.EPIC),
            createCard("末日火龙", Element.FIRE, 10, 10, 8, "传说中的毁灭之龙", CardRarity.LEGENDARY),

            // 稀有水元素卡牌
            createCard("深海女王", Element.WATER, 6, 7, 6, "统治深海的女王", CardRarity.RARE),
            createCard("冰霜巨人", Element.WATER, 7, 8, 7, "来自极地的巨人", CardRarity.EPIC),
            createCard("海洋之心", Element.WATER, 9, 9, 8, "蕴含海洋力量的神器", CardRarity.LEGENDARY),

            // 稀有土元素卡牌
            createCard("山脉守护者", Element.EARTH, 5, 8, 6, "守护山脉的古老存在", CardRarity.RARE),
            createCard("泰坦巨人", Element.EARTH, 8, 9, 7, "远古时代的巨人", CardRarity.EPIC),
            createCard("世界之树", Element.EARTH, 7, 12, 8, "连接天地的神树", CardRarity.LEGENDARY),

            // 稀有风元素卡牌
            createCard("风暴领主", Element.WIND, 8, 5, 6, "掌控风暴的领主", CardRarity.RARE),
            createCard("天空之王", Element.WIND, 9, 6, 7, "统治天空的王者", CardRarity.EPIC),
            createCard("虚空之风", Element.WIND, 10, 7, 8, "来自虚空的神秘力量", CardRarity.LEGENDARY)
        )
    }

    /**
     * 根据稀有度创建随机卡组
     */
    fun createRandomDeck(size: Int = 20): List<Card> {
        val allCards = createAllCards()
        return allCards.shuffled().take(size)
    }

    /**
     * 创建单张卡牌
     */
    private fun createCard(
        name: String,
        element: Element,
        attack: Int,
        health: Int,
        manaCost: Int,
        description: String,
        rarity: CardRarity = CardRarity.COMMON
    ): Card {
        return Card(
            name = name,
            element = element,
            baseAttack = attack,
            baseHealth = health,
            manaCost = manaCost,
            description = description,
            rarity = rarity
        )
    }

    /**
     * 根据元素类型获取卡牌
     */
    fun getCardsByElement(element: Element): List<Card> {
        return createAllCards().filter { it.element == element }
    }

    /**
     * 根据稀有度获取卡牌
     */
    fun getCardsByRarity(rarity: CardRarity): List<Card> {
        return createAllCards().filter { it.rarity == rarity }
    }

    /**
     * 根据法力消耗获取卡牌
     */
    fun getCardsByManaCost(manaCost: Int): List<Card> {
        return createAllCards().filter { it.manaCost == manaCost }
    }
}
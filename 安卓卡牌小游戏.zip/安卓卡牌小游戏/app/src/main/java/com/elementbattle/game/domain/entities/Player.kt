package com.elementbattle.game.domain.entities

import android.os.Parcelable
import kotlinx.parcelize.Parcelize

@Parcelize
data class Player(
    val id: String,
    val name: String,
    val health: Int = 30,
    val maxHealth: Int = 30,
    val mana: Int = 1,
    val maxMana: Int = 10,
    val deck: List<Card> = emptyList(),
    val hand: List<Card> = emptyList(),
    val field: List<Card> = emptyList(),
    val graveyard: List<Card> = emptyList(),
    val isAI: Boolean = false
) : Parcelable {

    companion object {
        const val MAX_HAND_SIZE = 10
        const val MAX_FIELD_SIZE = 5
        const val INITIAL_HAND_SIZE = 3
    }

    /**
     * 是否存活
     */
    val isAlive: Boolean
        get() = health > 0

    /**
     * 是否可以出牌
     */
    fun canPlayCard(card: Card): Boolean {
        return hand.contains(card) &&
               mana >= card.manaCost &&
               field.size < MAX_FIELD_SIZE
    }

    /**
     * 出牌
     */
    fun playCard(card: Card): Player {
        if (!canPlayCard(card)) return this

        return copy(
            hand = hand - card,
            field = field + card,
            mana = mana - card.manaCost
        )
    }

    /**
     * 抽卡
     */
    fun drawCard(): Player {
        if (deck.isEmpty() || hand.size >= MAX_HAND_SIZE) return this

        val cardToDraw = deck.first()
        return copy(
            deck = deck.drop(1),
            hand = hand + cardToDraw
        )
    }

    /**
     * 回合开始
     */
    fun startTurn(turnNumber: Int): Player {
        val newMana = (maxMana.coerceAtMost(turnNumber)).coerceAtLeast(1)
        val newField = field.map { it.resetTurn() }

        return copy(
            mana = newMana,
            field = newField
        ).drawCard()
    }

    /**
     * 受到伤害
     */
    fun takeDamage(damage: Int): Player {
        return copy(health = (health - damage).coerceAtLeast(0))
    }

    /**
     * 治疗
     */
    fun heal(amount: Int): Player {
        return copy(health = (health + amount).coerceAtMost(maxHealth))
    }

    /**
     * 移除死亡的卡牌
     */
    fun removeDeadCards(): Player {
        val (alive, dead) = field.partition { it.isAlive }
        return copy(
            field = alive,
            graveyard = graveyard + dead
        )
    }

    /**
     * 更新场上的卡牌
     */
    fun updateFieldCard(oldCard: Card, newCard: Card): Player {
        val newField = field.map { if (it.id == oldCard.id) newCard else it }
        return copy(field = newField)
    }

    /**
     * 获取可攻击的卡牌
     */
    fun getAttackableCards(): List<Card> {
        return field.filter { it.canAttack }
    }
}
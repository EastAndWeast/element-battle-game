package com.elementbattle.game.domain.entities

import android.os.Parcelable
import kotlinx.parcelize.Parcelize

sealed class GameState : Parcelable {

    @Parcelize
    object MainMenu : GameState()

    @Parcelize
    object Loading : GameState()

    @Parcelize
    data class Playing(
        val player: Player,
        val enemy: Player,
        val currentTurn: PlayerType,
        val turnNumber: Int = 1,
        val gamePhase: GamePhase = GamePhase.MAIN,
        val selectedCard: Card? = null,
        val selectedTarget: Card? = null,
        val lastAction: GameAction? = null
    ) : GameState() {

        val currentPlayer: Player
            get() = if (currentTurn == PlayerType.HUMAN) player else enemy

        val opponentPlayer: Player
            get() = if (currentTurn == PlayerType.HUMAN) enemy else player
    }

    @Parcelize
    data class GameOver(
        val winner: PlayerType?,
        val finalPlayer: Player,
        val finalEnemy: Player,
        val reason: GameOverReason
    ) : GameState()

    @Parcelize
    object Settings : GameState()
}

enum class PlayerType {
    HUMAN, AI
}

enum class GamePhase {
    MAIN,      // 主要阶段，可以出牌
    COMBAT,    // 战斗阶段，选择攻击目标
    END_TURN   // 回合结束阶段
}

enum class GameOverReason {
    PLAYER_DEFEATED,
    ENEMY_DEFEATED,
    PLAYER_QUIT,
    DRAW
}

sealed class GameAction : Parcelable {

    @Parcelize
    data class PlayCard(
        val card: Card,
        val player: PlayerType
    ) : GameAction()

    @Parcelize
    data class AttackCard(
        val attacker: Card,
        val target: Card,
        val player: PlayerType
    ) : GameAction()

    @Parcelize
    data class AttackPlayer(
        val attacker: Card,
        val target: PlayerType
    ) : GameAction()

    @Parcelize
    data class EndTurn(
        val player: PlayerType
    ) : GameAction()

    @Parcelize
    data class DrawCard(
        val card: Card,
        val player: PlayerType
    ) : GameAction()
}
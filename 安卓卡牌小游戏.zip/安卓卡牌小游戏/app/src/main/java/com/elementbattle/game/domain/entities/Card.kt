package com.elementbattle.game.domain.entities

import android.os.Parcelable
import kotlinx.parcelize.Parcelize
import java.util.UUID

@Parcelize
data class Card(
    val id: String = UUID.randomUUID().toString(),
    val name: String,
    val element: Element,
    val baseAttack: Int,
    val baseHealth: Int,
    val manaCost: Int,
    val description: String = "",
    val rarity: CardRarity = CardRarity.COMMON,
    // 运行时状态
    val currentHealth: Int = baseHealth,
    val isExhausted: Boolean = false, // 本回合是否已经攻击过
    val buffs: List<CardBuff> = emptyList()
) : Parcelable {

    /**
     * 获取当前攻击力（包含buff效果）
     */
    val currentAttack: Int
        get() = baseAttack + buffs.sumOf { it.attackBonus }

    /**
     * 是否存活
     */
    val isAlive: Boolean
        get() = currentHealth > 0

    /**
     * 是否可以攻击
     */
    val canAttack: Boolean
        get() = isAlive && !isExhausted

    /**
     * 攻击目标卡牌
     */
    fun attackCard(target: Card): Pair<Card, Card> {
        val damageToTarget = (currentAttack * element.getDamageMultiplier(target.element)).toInt()
        val damageToSelf = target.currentAttack

        val newTarget = target.copy(
            currentHealth = (target.currentHealth - damageToTarget).coerceAtLeast(0)
        )

        val newSelf = this.copy(
            currentHealth = (currentHealth - damageToSelf).coerceAtLeast(0),
            isExhausted = true
        )

        return Pair(newSelf, newTarget)
    }

    /**
     * 重置回合状态
     */
    fun resetTurn(): Card = copy(isExhausted = false)

    /**
     * 应用buff
     */
    fun applyBuff(buff: CardBuff): Card = copy(buffs = buffs + buff)

    /**
     * 移除过期的buff
     */
    fun removeExpiredBuffs(): Card = copy(buffs = buffs.filter { !it.isExpired })
}

enum class CardRarity(val displayName: String) {
    COMMON("普通"),
    RARE("稀有"),
    EPIC("史诗"),
    LEGENDARY("传说")
}

@Parcelize
data class CardBuff(
    val name: String,
    val attackBonus: Int = 0,
    val healthBonus: Int = 0,
    val duration: Int = 1, // 持续回合数，-1表示永久
    val turnsLeft: Int = duration
) : Parcelable {

    val isExpired: Boolean
        get() = turnsLeft <= 0 && duration != -1

    fun decreaseDuration(): CardBuff = copy(turnsLeft = turnsLeft - 1)
}
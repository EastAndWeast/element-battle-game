package com.elementbattle.game.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.elementbattle.game.R
import com.elementbattle.game.ui.theme.ElementBattleTheme
import com.elementbattle.game.ui.theme.ElementColors

@Composable
fun MainMenuScreen(
    onStartGame: () -> Unit,
    onSettings: () -> Unit,
    onExit: () -> Unit
) {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(
                brush = Brush.verticalGradient(
                    colors = listOf(
                        Color(0xFF1A1A2E),
                        Color(0xFF16213E),
                        Color(0xFF0F3460)
                    )
                )
            )
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(32.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            // 游戏标题
            Text(
                text = stringResource(R.string.app_name),
                style = MaterialTheme.typography.displayLarge.copy(
                    fontSize = 48.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color.White
                ),
                textAlign = TextAlign.Center
            )

            // 副标题
            Text(
                text = "元素相克，策略对战",
                style = MaterialTheme.typography.headlineMedium.copy(
                    color = Color(0xFFCCCCCC)
                ),
                textAlign = TextAlign.Center,
                modifier = Modifier.padding(top = 8.dp, bottom = 48.dp)
            )

            // 元素图标展示
            Row(
                modifier = Modifier.padding(bottom = 48.dp),
                horizontalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                ElementIcon("🔥", ElementColors.Fire)
                ElementIcon("💧", ElementColors.Water)
                ElementIcon("🌍", ElementColors.Earth)
                ElementIcon("💨", ElementColors.Wind)
            }

            // 菜单按钮
            Column(
                verticalArrangement = Arrangement.spacedBy(16.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                MenuButton(
                    text = stringResource(R.string.start_game),
                    onClick = onStartGame,
                    backgroundColor = ElementColors.Fire
                )

                MenuButton(
                    text = stringResource(R.string.settings),
                    onClick = onSettings,
                    backgroundColor = ElementColors.Water
                )

                MenuButton(
                    text = stringResource(R.string.exit),
                    onClick = onExit,
                    backgroundColor = Color(0xFF666666)
                )
            }

            Spacer(modifier = Modifier.height(32.dp))

            // 版本信息
            Text(
                text = "版本 1.0.0",
                style = MaterialTheme.typography.bodySmall.copy(
                    color = Color(0xFF888888)
                )
            )
        }
    }
}

@Composable
private fun ElementIcon(
    emoji: String,
    color: Color
) {
    Box(
        modifier = Modifier
            .size(60.dp)
            .background(
                color = color.copy(alpha = 0.2f),
                shape = RoundedCornerShape(12.dp)
            ),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = emoji,
            fontSize = 32.sp
        )
    }
}

@Composable
private fun MenuButton(
    text: String,
    onClick: () -> Unit,
    backgroundColor: Color
) {
    Button(
        onClick = onClick,
        modifier = Modifier
            .fillMaxWidth()
            .height(56.dp),
        colors = ButtonDefaults.buttonColors(
            containerColor = backgroundColor
        ),
        shape = RoundedCornerShape(12.dp)
    ) {
        Text(
            text = text,
            style = MaterialTheme.typography.headlineMedium.copy(
                fontWeight = FontWeight.Bold,
                color = Color.White
            )
        )
    }
}

@Preview(showBackground = true)
@Composable
fun MainMenuScreenPreview() {
    ElementBattleTheme {
        MainMenuScreen(
            onStartGame = {},
            onSettings = {},
            onExit = {}
        )
    }
}
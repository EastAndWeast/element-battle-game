package com.elementbattle.game.domain

import com.elementbattle.game.domain.entities.*
import com.elementbattle.game.domain.usecases.*
import kotlinx.coroutines.test.runTest
import org.junit.Before
import org.junit.Test
import org.junit.Assert.*
import org.mockito.Mock
import org.mockito.Mockito.*
import org.mockito.MockitoAnnotations

class GameEngineTest {

    @Mock
    private lateinit var mockCardFactory: CardFactory

    @Mock
    private lateinit var mockAIStrategy: AIStrategy

    private lateinit var gameEngine: GameEngine

    @Before
    fun setup() {
        MockitoAnnotations.openMocks(this)
        gameEngine = GameEngine(mockCardFactory, mockAIStrategy)

        // 模拟卡牌工厂返回测试卡组
        `when`(mockCardFactory.createStarterDeck()).thenReturn(createTestDeck())
    }

    private fun createTestDeck(): List<Card> {
        return listOf(
            Card("火焰精灵", Element.FIRE, 2, 1, 1),
            Card("水滴精灵", Element.WATER, 1, 3, 1),
            Card("岩石精灵", Element.EARTH, 1, 4, 1),
            Card("风之精灵", Element.WIND, 3, 1, 1),
            Card("烈焰战士", Element.FIRE, 3, 2, 2)
        )
    }

    @Test
    fun `test start new game`() {
        val gameState = gameEngine.startNewGame()

        assertTrue(gameState is GameState.Playing)
        assertEquals(PlayerType.HUMAN, gameState.currentTurn)
        assertEquals(1, gameState.turnNumber)
        assertEquals(30, gameState.player.health)
        assertEquals(30, gameState.enemy.health)
        assertEquals(Player.INITIAL_HAND_SIZE, gameState.player.hand.size)
        assertEquals(Player.INITIAL_HAND_SIZE, gameState.enemy.hand.size)
    }

    @Test
    fun `test play card valid`() {
        val gameState = gameEngine.startNewGame()
        val cardToPlay = gameState.player.hand.first()

        val newState = gameEngine.playCard(gameState, cardToPlay)

        assertTrue(newState is GameState.Playing)
        val playingState = newState as GameState.Playing
        assertEquals(gameState.player.hand.size - 1, playingState.player.hand.size)
        assertEquals(gameState.player.field.size + 1, playingState.player.field.size)
        assertTrue(playingState.player.field.contains(cardToPlay))
    }

    @Test
    fun `test play card invalid - not enough mana`() {
        val gameState = gameEngine.startNewGame()
        val expensiveCard = Card("昂贵卡牌", Element.FIRE, 5, 5, 10)
        val modifiedPlayer = gameState.player.copy(hand = gameState.player.hand + expensiveCard)
        val modifiedState = gameState.copy(player = modifiedPlayer)

        val newState = gameEngine.playCard(modifiedState, expensiveCard)

        assertEquals(modifiedState, newState) // 状态应该没有改变
    }

    @Test
    fun `test play card invalid - not player turn`() {
        val gameState = gameEngine.startNewGame().copy(currentTurn = PlayerType.AI)
        val cardToPlay = gameState.player.hand.first()

        val newState = gameEngine.playCard(gameState, cardToPlay)

        assertEquals(gameState, newState) // 状态应该没有改变
    }

    @Test
    fun `test card attack card`() {
        val attacker = Card("攻击者", Element.FIRE, 3, 2, 1)
        val target = Card("目标", Element.WIND, 2, 3, 1)

        val gameState = GameState.Playing(
            player = Player("player", "玩家", field = listOf(attacker)),
            enemy = Player("enemy", "敌人", field = listOf(target)),
            currentTurn = PlayerType.HUMAN
        )

        val newState = gameEngine.attackCard(gameState, attacker, target)

        assertTrue(newState is GameState.Playing)
        val playingState = newState as GameState.Playing

        // 检查攻击结果
        val newAttacker = playingState.player.field.first()
        val newTarget = playingState.enemy.field.firstOrNull()

        assertTrue(newAttacker.isExhausted)
        // 火克风，3 * 1.5 = 4.5 -> 4点伤害，目标应该死亡
        assertNull(newTarget) // 目标应该被移除
    }

    @Test
    fun `test end turn`() {
        val gameState = gameEngine.startNewGame()
        val originalTurnNumber = gameState.turnNumber

        val newState = gameEngine.endTurn(gameState)

        assertTrue(newState is GameState.Playing)
        val playingState = newState as GameState.Playing
        assertEquals(PlayerType.AI, playingState.currentTurn)
        assertEquals(originalTurnNumber, playingState.turnNumber) // AI回合，回合数不变
    }

    @Test
    fun `test game over - player defeated`() {
        val deadPlayer = Player("player", "玩家", health = 0)
        val gameState = GameState.Playing(
            player = deadPlayer,
            enemy = Player("enemy", "敌人"),
            currentTurn = PlayerType.HUMAN
        )

        val newState = gameEngine.endTurn(gameState)

        assertTrue(newState is GameState.GameOver)
        val gameOverState = newState as GameState.GameOver
        assertEquals(PlayerType.AI, gameOverState.winner)
        assertEquals(GameOverReason.PLAYER_DEFEATED, gameOverState.reason)
    }

    @Test
    fun `test game over - enemy defeated`() {
        val deadEnemy = Player("enemy", "敌人", health = 0)
        val gameState = GameState.Playing(
            player = Player("player", "玩家"),
            enemy = deadEnemy,
            currentTurn = PlayerType.HUMAN
        )

        val newState = gameEngine.endTurn(gameState)

        assertTrue(newState is GameState.GameOver)
        val gameOverState = newState as GameState.GameOver
        assertEquals(PlayerType.HUMAN, gameOverState.winner)
        assertEquals(GameOverReason.ENEMY_DEFEATED, gameOverState.reason)
    }

    @Test
    fun `test AI turn processing`() = runTest {
        val gameState = gameEngine.startNewGame().copy(currentTurn = PlayerType.AI)

        // 模拟AI策略
        `when`(mockAIStrategy.selectCardToPlay(any(), any(), any(), any())).thenReturn(null)
        `when`(mockAIStrategy.selectAttackTarget(any(), any(), any())).thenReturn(AITarget.None)

        val newState = gameEngine.processAITurn(gameState)

        assertTrue(newState is GameState.Playing)
        val playingState = newState as GameState.Playing
        assertEquals(PlayerType.HUMAN, playingState.currentTurn) // AI回合结束，轮到玩家
    }
}
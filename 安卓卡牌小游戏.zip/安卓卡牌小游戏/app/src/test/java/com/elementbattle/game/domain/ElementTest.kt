package com.elementbattle.game.domain

import com.elementbattle.game.domain.entities.Element
import org.junit.Test
import org.junit.Assert.*

class ElementTest {

    @Test
    fun `test element advantage relationships`() {
        // 测试元素克制关系
        assertEquals(Element.WIND, Element.FIRE.getAdvantageAgainst())
        assertEquals(Element.EARTH, Element.WIND.getAdvantageAgainst())
        assertEquals(Element.WATER, Element.EARTH.getAdvantageAgainst())
        assertEquals(Element.FIRE, Element.WATER.getAdvantageAgainst())
    }

    @Test
    fun `test element disadvantage relationships`() {
        // 测试元素被克制关系
        assertEquals(Element.WATER, Element.FIRE.getDisadvantageAgainst())
        assertEquals(Element.FIRE, Element.WIND.getDisadvantageAgainst())
        assertEquals(Element.WIND, Element.EARTH.getDisadvantageAgainst())
        assertEquals(Element.EARTH, Element.WATER.getDisadvantageAgainst())
    }

    @Test
    fun `test damage multiplier calculations`() {
        // 测试伤害倍率计算

        // 克制关系：伤害+50%
        assertEquals(1.5f, Element.FIRE.getDamageMultiplier(Element.WIND), 0.01f)
        assertEquals(1.5f, Element.WIND.getDamageMultiplier(Element.EARTH), 0.01f)
        assertEquals(1.5f, Element.EARTH.getDamageMultiplier(Element.WATER), 0.01f)
        assertEquals(1.5f, Element.WATER.getDamageMultiplier(Element.FIRE), 0.01f)

        // 被克制关系：伤害-25%
        assertEquals(0.75f, Element.FIRE.getDamageMultiplier(Element.WATER), 0.01f)
        assertEquals(0.75f, Element.WIND.getDamageMultiplier(Element.FIRE), 0.01f)
        assertEquals(0.75f, Element.EARTH.getDamageMultiplier(Element.WIND), 0.01f)
        assertEquals(0.75f, Element.WATER.getDamageMultiplier(Element.EARTH), 0.01f)

        // 相同元素：正常伤害
        assertEquals(1.0f, Element.FIRE.getDamageMultiplier(Element.FIRE), 0.01f)
        assertEquals(1.0f, Element.WATER.getDamageMultiplier(Element.WATER), 0.01f)
        assertEquals(1.0f, Element.EARTH.getDamageMultiplier(Element.EARTH), 0.01f)
        assertEquals(1.0f, Element.WIND.getDamageMultiplier(Element.WIND), 0.01f)
    }

    @Test
    fun `test element properties`() {
        // 测试元素属性
        assertEquals("火", Element.FIRE.displayName)
        assertEquals("🔥", Element.FIRE.emoji)
        assertEquals("#FF4444", Element.FIRE.colorHex)

        assertEquals("水", Element.WATER.displayName)
        assertEquals("💧", Element.WATER.emoji)
        assertEquals("#4488FF", Element.WATER.colorHex)

        assertEquals("土", Element.EARTH.displayName)
        assertEquals("🌍", Element.EARTH.emoji)
        assertEquals("#8B4513", Element.EARTH.colorHex)

        assertEquals("风", Element.WIND.displayName)
        assertEquals("💨", Element.WIND.emoji)
        assertEquals("#32CD32", Element.WIND.colorHex)
    }

    @Test
    fun `test circular advantage relationship`() {
        // 测试循环克制关系的完整性
        val elements = Element.values()

        for (element in elements) {
            val advantage = element.getAdvantageAgainst()
            val disadvantage = element.getDisadvantageAgainst()

            // 确保每个元素都有明确的克制和被克制关系
            assertNotEquals(element, advantage)
            assertNotEquals(element, disadvantage)
            assertNotEquals(advantage, disadvantage)

            // 确保克制关系是相互的
            assertEquals(element, disadvantage.getAdvantageAgainst())
        }
    }
}
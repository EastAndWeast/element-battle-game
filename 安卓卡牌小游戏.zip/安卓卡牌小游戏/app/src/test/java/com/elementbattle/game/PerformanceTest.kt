package com.elementbattle.game

import com.elementbattle.game.domain.entities.*
import com.elementbattle.game.domain.usecases.*
import kotlinx.coroutines.test.runTest
import org.junit.Test
import org.junit.Assert.*
import kotlin.system.measureTimeMillis

class PerformanceTest {

    private val cardFactory = CardFactory()
    private val aiStrategy = SimpleAIStrategy()
    private val gameEngine = GameEngine(cardFactory, aiStrategy)

    @Test
    fun `test game initialization performance`() {
        val times = mutableListOf<Long>()

        repeat(100) {
            val time = measureTimeMillis {
                gameEngine.startNewGame()
            }
            times.add(time)
        }

        val averageTime = times.average()
        val maxTime = times.maxOrNull() ?: 0L

        println("游戏初始化性能测试:")
        println("平均时间: ${averageTime}ms")
        println("最大时间: ${maxTime}ms")

        // 游戏初始化应该在100ms内完成
        assertTrue("游戏初始化时间过长: ${averageTime}ms", averageTime < 100)
        assertTrue("游戏初始化最大时间过长: ${maxTime}ms", maxTime < 200)
    }

    @Test
    fun `test card creation performance`() {
        val times = mutableListOf<Long>()

        repeat(1000) {
            val time = measureTimeMillis {
                cardFactory.createStarterDeck()
            }
            times.add(time)
        }

        val averageTime = times.average()
        val maxTime = times.maxOrNull() ?: 0L

        println("卡牌创建性能测试:")
        println("平均时间: ${averageTime}ms")
        println("最大时间: ${maxTime}ms")

        // 卡牌创建应该在10ms内完成
        assertTrue("卡牌创建时间过长: ${averageTime}ms", averageTime < 10)
    }

    @Test
    fun `test AI decision performance`() = runTest {
        val gameState = gameEngine.startNewGame()
        val hand = gameState.enemy.hand
        val field = gameState.enemy.field
        val enemyField = gameState.player.field
        val mana = gameState.enemy.mana

        val times = mutableListOf<Long>()

        repeat(100) {
            val time = measureTimeMillis {
                aiStrategy.selectCardToPlay(hand, field, enemyField, mana)
            }
            times.add(time)
        }

        val averageTime = times.average()
        val maxTime = times.maxOrNull() ?: 0L

        println("AI决策性能测试:")
        println("平均时间: ${averageTime}ms")
        println("最大时间: ${maxTime}ms")

        // AI决策应该在50ms内完成
        assertTrue("AI决策时间过长: ${averageTime}ms", averageTime < 50)
        assertTrue("AI决策最大时间过长: ${maxTime}ms", maxTime < 100)
    }

    @Test
    fun `test card combat calculation performance`() {
        val fireCard = Card("火焰战士", Element.FIRE, 4, 3, 2)
        val windCard = Card("风之精灵", Element.WIND, 2, 4, 1)

        val times = mutableListOf<Long>()

        repeat(10000) {
            val time = measureTimeMillis {
                fireCard.attackCard(windCard)
            }
            times.add(time)
        }

        val averageTime = times.average()
        val maxTime = times.maxOrNull() ?: 0L

        println("卡牌战斗计算性能测试:")
        println("平均时间: ${averageTime}ms")
        println("最大时间: ${maxTime}ms")

        // 卡牌战斗计算应该在1ms内完成
        assertTrue("卡牌战斗计算时间过长: ${averageTime}ms", averageTime < 1)
    }

    @Test
    fun `test element damage calculation performance`() {
        val times = mutableListOf<Long>()

        repeat(100000) {
            val time = measureTimeMillis {
                Element.FIRE.getDamageMultiplier(Element.WIND)
                Element.WATER.getDamageMultiplier(Element.FIRE)
                Element.EARTH.getDamageMultiplier(Element.WATER)
                Element.WIND.getDamageMultiplier(Element.EARTH)
            }
            times.add(time)
        }

        val averageTime = times.average()

        println("元素伤害计算性能测试:")
        println("平均时间: ${averageTime}ms")

        // 元素伤害计算应该非常快
        assertTrue("元素伤害计算时间过长: ${averageTime}ms", averageTime < 0.1)
    }

    @Test
    fun `test memory usage during game`() {
        val runtime = Runtime.getRuntime()

        // 记录初始内存
        runtime.gc()
        val initialMemory = runtime.totalMemory() - runtime.freeMemory()

        // 创建多个游戏状态
        val gameStates = mutableListOf<GameState.Playing>()
        repeat(100) {
            gameStates.add(gameEngine.startNewGame())
        }

        // 记录使用后内存
        runtime.gc()
        val usedMemory = runtime.totalMemory() - runtime.freeMemory()
        val memoryIncrease = usedMemory - initialMemory

        println("内存使用测试:")
        println("初始内存: ${initialMemory / 1024 / 1024}MB")
        println("使用后内存: ${usedMemory / 1024 / 1024}MB")
        println("内存增长: ${memoryIncrease / 1024 / 1024}MB")

        // 100个游戏状态不应该占用超过50MB内存
        assertTrue("内存使用过多: ${memoryIncrease / 1024 / 1024}MB",
                  memoryIncrease < 50 * 1024 * 1024)
    }

    @Test
    fun `test concurrent game operations`() = runTest {
        val times = mutableListOf<Long>()

        repeat(10) {
            val time = measureTimeMillis {
                // 模拟并发操作
                val gameState = gameEngine.startNewGame()
                val card = gameState.player.hand.first()

                // 执行多个操作
                gameEngine.playCard(gameState, card)
                gameEngine.endTurn(gameState)
            }
            times.add(time)
        }

        val averageTime = times.average()

        println("并发操作性能测试:")
        println("平均时间: ${averageTime}ms")

        // 并发操作应该在合理时间内完成
        assertTrue("并发操作时间过长: ${averageTime}ms", averageTime < 500)
    }
}
package com.elementbattle.game.domain

import com.elementbattle.game.domain.entities.*
import org.junit.Test
import org.junit.Assert.*

class CardTest {

    private fun createTestCard(
        name: String = "测试卡牌",
        element: Element = Element.FIRE,
        attack: Int = 3,
        health: Int = 2,
        manaCost: Int = 2
    ): Card {
        return Card(
            name = name,
            element = element,
            baseAttack = attack,
            baseHealth = health,
            manaCost = manaCost
        )
    }

    @Test
    fun `test card creation`() {
        val card = createTestCard()

        assertEquals("测试卡牌", card.name)
        assertEquals(Element.FIRE, card.element)
        assertEquals(3, card.baseAttack)
        assertEquals(2, card.baseHealth)
        assertEquals(2, card.manaCost)
        assertEquals(2, card.currentHealth)
        assertEquals(3, card.currentAttack)
        assertTrue(card.isAlive)
        assertFalse(card.isExhausted)
    }

    @Test
    fun `test card attack calculation with buffs`() {
        val card = createTestCard(attack = 3)
        val buff = CardBuff("攻击增强", attackBonus = 2)
        val buffedCard = card.applyBuff(buff)

        assertEquals(3, card.currentAttack)
        assertEquals(5, buffedCard.currentAttack)
    }

    @Test
    fun `test card combat`() {
        val fireCard = createTestCard("火焰战士", Element.FIRE, 4, 3, 2)
        val windCard = createTestCard("风之精灵", Element.WIND, 2, 4, 1)

        val (newFireCard, newWindCard) = fireCard.attackCard(windCard)

        // 火克风，伤害应该是 4 * 1.5 = 6
        assertEquals(0, newWindCard.currentHealth) // 4 - 6 = -2, 最小为0
        // 火卡受到风卡的2点伤害
        assertEquals(1, newFireCard.currentHealth) // 3 - 2 = 1
        assertTrue(newFireCard.isExhausted)
    }

    @Test
    fun `test card death`() {
        val card = createTestCard(health = 1)
        val attacker = createTestCard(attack = 2)

        val (_, target) = attacker.attackCard(card)

        assertFalse(target.isAlive)
        assertEquals(0, target.currentHealth)
    }

    @Test
    fun `test card exhaustion`() {
        val card = createTestCard()

        assertTrue(card.canAttack)
        assertFalse(card.isExhausted)

        val exhaustedCard = card.copy(isExhausted = true)
        assertFalse(exhaustedCard.canAttack)
        assertTrue(exhaustedCard.isExhausted)

        val resetCard = exhaustedCard.resetTurn()
        assertTrue(resetCard.canAttack)
        assertFalse(resetCard.isExhausted)
    }

    @Test
    fun `test buff system`() {
        val card = createTestCard(attack = 2, health = 3)
        val attackBuff = CardBuff("力量增强", attackBonus = 3, duration = 2)

        val buffedCard = card.applyBuff(attackBuff)
        assertEquals(5, buffedCard.currentAttack) // 2 + 3
        assertEquals(1, buffedCard.buffs.size)

        val decreasedBuff = buffedCard.buffs.first().decreaseDuration()
        assertEquals(1, decreasedBuff.turnsLeft)
        assertFalse(decreasedBuff.isExpired)

        val expiredBuff = decreasedBuff.decreaseDuration()
        assertEquals(0, expiredBuff.turnsLeft)
        assertTrue(expiredBuff.isExpired)
    }

    @Test
    fun `test permanent buff`() {
        val card = createTestCard()
        val permanentBuff = CardBuff("永久强化", attackBonus = 1, duration = -1)

        val buffedCard = card.applyBuff(permanentBuff)
        val decreasedBuff = buffedCard.buffs.first().decreaseDuration()

        assertFalse(decreasedBuff.isExpired)
        assertEquals(-2, decreasedBuff.turnsLeft) // -1 - 1 = -2
    }

    @Test
    fun `test remove expired buffs`() {
        val card = createTestCard()
        val expiredBuff = CardBuff("过期buff", attackBonus = 1, duration = 1, turnsLeft = 0)
        val activeBuff = CardBuff("活跃buff", attackBonus = 2, duration = 2, turnsLeft = 1)

        val cardWithBuffs = card.copy(buffs = listOf(expiredBuff, activeBuff))
        val cleanedCard = cardWithBuffs.removeExpiredBuffs()

        assertEquals(1, cleanedCard.buffs.size)
        assertEquals("活跃buff", cleanedCard.buffs.first().name)
    }
}
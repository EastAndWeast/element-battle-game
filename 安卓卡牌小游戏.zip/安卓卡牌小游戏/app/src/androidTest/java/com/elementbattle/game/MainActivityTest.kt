package com.elementbattle.game

import androidx.compose.ui.test.*
import androidx.compose.ui.test.junit4.createAndroidComposeRule
import androidx.test.ext.junit.runners.AndroidJUnit4
import dagger.hilt.android.testing.HiltAndroidRule
import dagger.hilt.android.testing.HiltAndroidTest
import org.junit.Before
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith

@HiltAndroidTest
@RunWith(AndroidJUnit4::class)
class MainActivityTest {

    @get:Rule(order = 0)
    val hiltRule = HiltAndroidRule(this)

    @get:Rule(order = 1)
    val composeTestRule = createAndroidComposeRule<MainActivity>()

    @Before
    fun setup() {
        hiltRule.inject()
    }

    @Test
    fun testMainMenuDisplayed() {
        // 验证主菜单界面显示
        composeTestRule.onNodeWithText("元素对战").assertIsDisplayed()
        composeTestRule.onNodeWithText("开始游戏").assertIsDisplayed()
        composeTestRule.onNodeWithText("设置").assertIsDisplayed()
        composeTestRule.onNodeWithText("退出").assertIsDisplayed()
    }

    @Test
    fun testStartGameNavigation() {
        // 测试开始游戏按钮导航
        composeTestRule.onNodeWithText("开始游戏").performClick()

        // 等待游戏界面加载
        composeTestRule.waitForIdle()

        // 验证游戏界面元素
        composeTestRule.onNodeWithText("结束回合").assertIsDisplayed()
    }

    @Test
    fun testSettingsNavigation() {
        // 测试设置按钮导航
        composeTestRule.onNodeWithText("设置").performClick()

        // 验证设置界面
        composeTestRule.onNodeWithText("音效").assertIsDisplayed()
        composeTestRule.onNodeWithText("背景音乐").assertIsDisplayed()
        composeTestRule.onNodeWithText("震动").assertIsDisplayed()

        // 测试返回按钮
        composeTestRule.onNodeWithText("← 返回").performClick()
        composeTestRule.onNodeWithText("元素对战").assertIsDisplayed()
    }

    @Test
    fun testElementIconsDisplayed() {
        // 验证元素图标显示
        composeTestRule.onNodeWithText("🔥").assertIsDisplayed()
        composeTestRule.onNodeWithText("💧").assertIsDisplayed()
        composeTestRule.onNodeWithText("🌍").assertIsDisplayed()
        composeTestRule.onNodeWithText("💨").assertIsDisplayed()
    }

    @Test
    fun testGameFlow() {
        // 测试完整游戏流程

        // 1. 开始游戏
        composeTestRule.onNodeWithText("开始游戏").performClick()
        composeTestRule.waitForIdle()

        // 2. 验证游戏界面加载
        composeTestRule.onNodeWithText("结束回合").assertIsDisplayed()

        // 3. 尝试结束回合
        composeTestRule.onNodeWithText("结束回合").performClick()
        composeTestRule.waitForIdle()

        // 4. 验证AI回合提示
        composeTestRule.onNodeWithText("AI回合中...").assertIsDisplayed()

        // 5. 等待AI回合结束
        composeTestRule.waitUntil(timeoutMillis = 5000) {
            composeTestRule.onAllNodesWithText("结束回合").fetchSemanticsNodes().isNotEmpty()
        }
    }

    @Test
    fun testBackToMenuFromGame() {
        // 测试从游戏返回主菜单
        composeTestRule.onNodeWithText("开始游戏").performClick()
        composeTestRule.waitForIdle()

        composeTestRule.onNodeWithText("返回菜单").performClick()
        composeTestRule.waitForIdle()

        composeTestRule.onNodeWithText("元素对战").assertIsDisplayed()
    }
}
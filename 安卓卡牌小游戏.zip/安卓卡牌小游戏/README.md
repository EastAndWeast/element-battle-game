# 元素对战 🎮

一款基于元素相克机制的策略卡牌手游，使用 Kotlin 和 Jetpack Compose 开发。

## 📱 游戏特色

- 🔥💧🌍💨 **四大元素系统**：火、水、土、风相互克制
- 🤖 **智能AI对手**：多种难度的AI策略
- 🎨 **现代UI设计**：使用 Jetpack Compose 构建
- 🎵 **音效系统**：沉浸式游戏体验
- ⚡ **快节奏对战**：单局5-10分钟

## 🎯 游戏玩法

### 元素相克关系
```
火 🔥 → 风 💨 → 土 🌍 → 水 💧 → 火 🔥
```

### 基本规则
- 初始生命值：30点
- 初始法力值：1点，每回合+1（最大10点）
- 初始手牌：3张，每回合抽1张
- 场上最多同时存在5张卡牌
- 先将对手生命值降为0者获胜

## 🛠️ 技术栈

### 核心技术
- **语言**：Kotlin 100%
- **UI框架**：Jetpack Compose
- **架构模式**：MVVM + Repository Pattern
- **依赖注入**：Hilt
- **异步处理**：Kotlin Coroutines + Flow
- **本地存储**：Room Database
- **音频处理**：MediaPlayer + SoundPool

### 开发工具
- Android Studio Hedgehog | 2023.1.1+
- Gradle 8.1.2
- Kotlin 1.9.10
- Compose BOM 2023.10.01

## 🚀 快速开始

### 方法1：云端自动构建（推荐）⭐

**无需安装任何开发环境，直接获得APK文件！**

1. **运行快速开始脚本**
   ```bash
   ./quick_start.sh
   ```

2. **或手动上传到GitHub**
   - 访问 https://github.com 创建账户
   - 创建新仓库 `element-battle-game`
   - 上传项目文件
   - 等待自动构建（10-15分钟）
   - 下载生成的APK文件

3. **详细说明**
   - 查看 `GITHUB_BUILD_GUIDE.md` 获取完整指南

### 方法2：本地开发环境

#### 环境要求
- Android Studio Hedgehog 或更高版本
- JDK 8 或更高版本
- Android SDK API Level 23+ (Android 6.0+)
- Gradle 8.0+

#### 克隆项目
```bash
git clone https://github.com/your-username/element-battle.git
cd element-battle
```

#### 构建项目
```bash
# 构建调试版本
./gradlew assembleDebug

# 运行测试
./gradlew test

# 构建发布版本（需要先生成密钥库）
./scripts/generate_keystore.sh
./scripts/build_release.sh
```

## 📦 发布构建

### 生成签名密钥库
```bash
./scripts/generate_keystore.sh
```

### 构建发布版本
```bash
./scripts/build_release.sh
```

发布版APK将生成在 `releases/` 目录中。

## 🧪 测试

### 运行单元测试
```bash
./gradlew test
```

### 运行Android测试
```bash
./gradlew connectedAndroidTest
```

### 运行性能测试
```bash
./gradlew test --tests="*PerformanceTest"
```

## 📁 项目结构

```
app/
├── src/
│   ├── main/
│   │   ├── java/com/elementbattle/game/
│   │   │   ├── ui/                 # UI层
│   │   │   │   ├── screens/        # 界面
│   │   │   │   ├── components/     # 组件
│   │   │   │   ├── theme/          # 主题
│   │   │   │   └── navigation/     # 导航
│   │   │   ├── domain/             # 业务逻辑层
│   │   │   │   ├── entities/       # 实体类
│   │   │   │   ├── usecases/       # 用例
│   │   │   │   └── repository/     # 仓库接口
│   │   │   ├── data/               # 数据层
│   │   │   │   ├── repository/     # 仓库实现
│   │   │   │   ├── database/       # 数据库
│   │   │   │   └── audio/          # 音频管理
│   │   │   └── di/                 # 依赖注入
│   │   └── res/                    # 资源文件
│   ├── test/                       # 单元测试
│   └── androidTest/                # 集成测试
├── docs/                           # 文档
├── scripts/                        # 构建脚本
└── releases/                       # 发布文件
```

## 🎮 游戏截图

> 注：实际截图需要在真实设备上运行游戏后添加

## 🤝 贡献指南

1. Fork 项目
2. 创建特性分支 (`git checkout -b feature/AmazingFeature`)
3. 提交更改 (`git commit -m 'Add some AmazingFeature'`)
4. 推送到分支 (`git push origin feature/AmazingFeature`)
5. 开启 Pull Request

## 📄 许可证

本项目采用 MIT 许可证 - 查看 [LICENSE](LICENSE) 文件了解详情。

## 👥 开发团队

- **产品经理** - 游戏设计与需求分析
- **UI设计师** - 界面设计与用户体验
- **CTO** - 技术架构与开发规范
- **工程师** - 核心开发与UI实现
- **测试工程师** - 质量保证与测试
- **运维工程师** - 部署与发布管理

## 📞 联系我们

- 项目主页：[GitHub Repository](https://github.com/your-username/element-battle)
- 问题反馈：[Issues](https://github.com/your-username/element-battle/issues)
- 邮箱：elementbattle@example.com

## 🔄 版本历史

### v1.0.0 (2024-01-01)
- ✨ 初始版本发布
- 🎮 基础游戏玩法实现
- 🤖 AI对手系统
- 🎨 Jetpack Compose UI
- 🎵 音效系统
- 📱 Android 6.0+ 支持

---

**享受游戏！** 🎉
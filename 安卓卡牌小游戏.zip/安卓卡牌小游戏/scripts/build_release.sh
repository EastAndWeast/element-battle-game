#!/bin/bash

# 元素对战 - 发布版本构建脚本
# 作者：运维工程师
# 版本：1.0

set -e  # 遇到错误立即退出

echo "🚀 开始构建元素对战发布版本..."

# 颜色定义
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# 检查必要工具
check_tools() {
    echo -e "${BLUE}📋 检查构建工具...${NC}"

    if ! command -v ./gradlew &> /dev/null; then
        echo -e "${RED}❌ Gradle Wrapper 未找到${NC}"
        exit 1
    fi

    if ! command -v keytool &> /dev/null; then
        echo -e "${YELLOW}⚠️  keytool 未找到，将跳过密钥库检查${NC}"
    fi

    echo -e "${GREEN}✅ 构建工具检查完成${NC}"
}

# 清理项目
clean_project() {
    echo -e "${BLUE}🧹 清理项目...${NC}"
    ./gradlew clean
    echo -e "${GREEN}✅ 项目清理完成${NC}"
}

# 运行测试
run_tests() {
    echo -e "${BLUE}🧪 运行测试...${NC}"

    echo "运行单元测试..."
    ./gradlew test

    echo "运行Android测试..."
    ./gradlew connectedAndroidTest || echo -e "${YELLOW}⚠️  Android测试失败或设备未连接${NC}"

    echo -e "${GREEN}✅ 测试完成${NC}"
}

# 检查签名配置
check_signing() {
    echo -e "${BLUE}🔐 检查签名配置...${NC}"

    if [ ! -f "app/keystore.properties" ]; then
        echo -e "${RED}❌ 签名配置文件不存在: app/keystore.properties${NC}"
        echo "请创建签名配置文件或运行: ./scripts/generate_keystore.sh"
        exit 1
    fi

    # 读取配置
    source app/keystore.properties

    if [ ! -f "app/$storeFile" ]; then
        echo -e "${RED}❌ 密钥库文件不存在: app/$storeFile${NC}"
        echo "请生成密钥库文件或运行: ./scripts/generate_keystore.sh"
        exit 1
    fi

    echo -e "${GREEN}✅ 签名配置检查完成${NC}"
}

# 构建发布版本
build_release() {
    echo -e "${BLUE}🔨 构建发布版本...${NC}"

    ./gradlew assembleRelease

    if [ $? -eq 0 ]; then
        echo -e "${GREEN}✅ 发布版本构建成功${NC}"
    else
        echo -e "${RED}❌ 发布版本构建失败${NC}"
        exit 1
    fi
}

# 生成构建报告
generate_report() {
    echo -e "${BLUE}📊 生成构建报告...${NC}"

    APK_PATH="app/build/outputs/apk/release/app-release.apk"

    if [ -f "$APK_PATH" ]; then
        APK_SIZE=$(du -h "$APK_PATH" | cut -f1)
        echo -e "${GREEN}📱 APK文件: $APK_PATH${NC}"
        echo -e "${GREEN}📏 APK大小: $APK_SIZE${NC}"

        # 获取版本信息
        VERSION_NAME=$(grep "versionName" app/build.gradle | sed 's/.*"\(.*\)".*/\1/')
        VERSION_CODE=$(grep "versionCode" app/build.gradle | sed 's/.*\([0-9]\+\).*/\1/')

        echo -e "${GREEN}🏷️  版本名称: $VERSION_NAME${NC}"
        echo -e "${GREEN}🔢 版本代码: $VERSION_CODE${NC}"

        # 创建发布目录
        RELEASE_DIR="releases/v$VERSION_NAME"
        mkdir -p "$RELEASE_DIR"

        # 复制APK到发布目录
        cp "$APK_PATH" "$RELEASE_DIR/ElementBattle-v$VERSION_NAME.apk"

        # 生成校验和
        cd "$RELEASE_DIR"
        sha256sum "ElementBattle-v$VERSION_NAME.apk" > "ElementBattle-v$VERSION_NAME.apk.sha256"
        cd - > /dev/null

        echo -e "${GREEN}📦 发布文件已保存到: $RELEASE_DIR${NC}"
    else
        echo -e "${RED}❌ APK文件未找到${NC}"
        exit 1
    fi
}

# 主函数
main() {
    echo -e "${BLUE}🎮 元素对战 - 发布版本构建${NC}"
    echo "=================================="

    check_tools
    clean_project

    # 可选：运行测试
    if [ "$1" != "--skip-tests" ]; then
        run_tests
    else
        echo -e "${YELLOW}⚠️  跳过测试${NC}"
    fi

    check_signing
    build_release
    generate_report

    echo "=================================="
    echo -e "${GREEN}🎉 构建完成！${NC}"
    echo -e "${GREEN}📱 可以安装APK文件到Android设备进行测试${NC}"
}

# 执行主函数
main "$@"
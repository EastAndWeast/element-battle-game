#!/bin/bash

# 元素对战 - 密钥库生成脚本
# 作者：运维工程师
# 版本：1.0

set -e

echo "🔐 生成Android签名密钥库..."

# 颜色定义
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m'

# 检查keytool工具
if ! command -v keytool &> /dev/null; then
    echo -e "${RED}❌ keytool 工具未找到${NC}"
    echo "请确保已安装Java JDK"
    exit 1
fi

# 配置信息
KEYSTORE_FILE="app/release-key.keystore"
KEY_ALIAS="elementbattle"
VALIDITY_DAYS=10000

echo -e "${BLUE}📋 密钥库配置信息：${NC}"
echo "文件路径: $KEYSTORE_FILE"
echo "密钥别名: $KEY_ALIAS"
echo "有效期: $VALIDITY_DAYS 天"
echo ""

# 检查是否已存在密钥库
if [ -f "$KEYSTORE_FILE" ]; then
    echo -e "${YELLOW}⚠️  密钥库文件已存在: $KEYSTORE_FILE${NC}"
    read -p "是否要覆盖现有密钥库？(y/N): " -n 1 -r
    echo
    if [[ ! $REPLY =~ ^[Yy]$ ]]; then
        echo "操作已取消"
        exit 0
    fi
    rm -f "$KEYSTORE_FILE"
fi

echo -e "${BLUE}🔑 开始生成密钥库...${NC}"
echo "请按提示输入信息（可以使用默认值）："

# 生成密钥库
keytool -genkey \
    -v \
    -keystore "$KEYSTORE_FILE" \
    -alias "$KEY_ALIAS" \
    -keyalg RSA \
    -keysize 2048 \
    -validity $VALIDITY_DAYS \
    -storepass elementbattle2024 \
    -keypass elementbattle2024 \
    -dname "CN=Element Battle, OU=Game Development, O=Element Battle Studio, L=Shanghai, ST=Shanghai, C=CN"

if [ $? -eq 0 ]; then
    echo -e "${GREEN}✅ 密钥库生成成功！${NC}"
    echo ""
    echo -e "${BLUE}📄 密钥库信息：${NC}"
    keytool -list -v -keystore "$KEYSTORE_FILE" -storepass elementbattle2024

    echo ""
    echo -e "${GREEN}🎉 设置完成！${NC}"
    echo -e "${YELLOW}⚠️  重要提醒：${NC}"
    echo "1. 请妥善保管密钥库文件和密码"
    echo "2. 密钥库文件已添加到 .gitignore，不会被提交到版本控制"
    echo "3. 在生产环境中，请使用更强的密码"
    echo "4. 现在可以运行 ./scripts/build_release.sh 来构建发布版本"
else
    echo -e "${RED}❌ 密钥库生成失败${NC}"
    exit 1
fi